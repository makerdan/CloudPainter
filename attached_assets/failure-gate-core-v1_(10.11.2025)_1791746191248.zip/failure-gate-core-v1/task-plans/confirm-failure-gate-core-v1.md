[REGRESSION-GUARD] Classification: not-applicable. Guard: self-satisfying.

# Confirm & Harden: failure-gate-core

<!-- regression-guard: not-applicable -->

## Task identity and dependency

Target: Custom Skills Workbench, /@makerdantheman/Custom-Skills-Workbench. dependsOn: install-failure-gate-core-v1, resolved to the actual primary by the same batch creation. Native task ref: not created here. No local authorization/runtime ID is allocated. This is independent definition confirmation only, not installation of the Gate's feature/runtime.

## Scope and original input

Read the complete finalized primary plan, including its original independent retained-scope specification and complete frozen candidate; verify its actual installed canonical deliverable is accessible. Read .agents/skills/failure-gate-core/SKILL.md and compare each original obligation and acceptance item. Native lifecycle/dependency alone is not delivery. Missing original complete specification or ambiguous delivery blocks confirmation; do not derive criteria solely from the installed file.

Repair authority is exclusively .agents/skills/failure-gate-core/SKILL.md. No runtime implementation, resource/plan rewrite, publication or activation. Record findings/results in the confirmation conversation, not new repository report files. Preserve the separate canonical installation and runtime claims.

## Steps

1. Independently inspect the delivered file against every original primary requirement and the nine shared checks below.
2. List every gap, incorrect section or missing requirement in the task conversation BEFORE patching. No silent edits.
3. If correction would materially replace/delete more than half of nonblank body lines after YAML (mechanical formatting excluded), stop: add a clearly labeled findings HTML comment immediately after front matter and before the first heading, then report a separate rewrite is needed without creating/editing that task. Do not use the threshold to avoid targeted repairs.
4. Otherwise patch only the exact target file to satisfy the original scope. Do not add speculative advanced capabilities or use full-v4 references as dependencies.
5. Re-read the complete corrected file and check all shared criteria and both fixed confirmation additions. Report findings/edits/unmet criteria honestly; fresh independent post-repair acceptance is distinct if separately required by host policy. No runtime validation or installation-series advancement.

## Done looks like

1. The sole installed definition is .agents/skills/failure-gate-core/SKILL.md, with valid front matter name failure-gate-core and an explicit Failure Gate Core v1 heading.
2. The file is a self-contained portable Core contract, with no normative dependency on full Failure Gate v4, fixed project/stack/CLI/task-service assumption, or universal installation task count.
3. The file requires permanent transactional project-local Task IDs, one registered authorized tier, exact plan/decision/version bindings, atomic audit and authentic supported approval without platform-status or agent-flag substitutes.
4. The file requires independently approved finite whole-entry supervision, pre-dispatch registration, transitive owned-child containment, retained deadline/consumption lineage, single-flight/resource exclusion, and fail-closed handling of uncertainty.
5. The file requires minimal durable indexed raw evidence, actual tested contents/environment and complete native results, preserves independent callers, and rejects ignored failures, lucky-retry erasure, missing/skipped/stale/direct evidence and late-zero success.
6. The file requires current checked validated completion with effective installed final-writer proof and separate truthful owner_direction closure/readers, preserving failures/repairs and safe terminal permission release.
7. The file requires restart persistence, actual authorized isolated host-format restore with post-backup committed-ID reconciliation/old-writer fencing, and separately acknowledged exact retained-error recovery without history/counter resets or lease deletion.
8. The file explicitly excludes baseline/provenance/flakiness/auxiliary diagnostics, unrelated-process reclaim, portable export/import, automated progression/pruning and remote/distributed dispatch, without misclassifying retained owned cleanup or checked reruns as excluded.
9. The file separates definition installation, implementation, adoption, bootstrap permission, task approval, ordinary cutover and independent acceptance; it neither activates Core nor claims full v4 compliance or control of platform task completion.
10. No section is vague, self-referential, or deferred to future work.
11. A future Planner reading the skill file cold could follow it without ambiguity.

## Must NOT do

- Make any changes outside .agents/skills/failure-gate-core/SKILL.md.
- Refactor or modify adjacent skills.
- Add speculative content beyond what the original spec called for.
- Expand scope to include feature-code changes inspired by the skill's topic.
- Silently fix gaps without first listing them.

## Pre-existing failures to ignore

None authorized. Preserve historical failures; runtime tests and baseline classification are outside this file-only confirmation.

## Validation

Bounded file-content comparison against the complete original primary specification; no imports, syntax/guard/test/build commands, package operations, Gate stores or live process actions. Source confirmation is not actual runtime readiness, adoption, cutover or workspace publication. Missing input/permission remains BLOCKED, not a guessed pass.

## Regression Guard

**Self-satisfying** — this task's deliverable is file-only independent confirmation/hardening of .agents/skills/failure-gate-core/SKILL.md against the complete original specification.

## Relevant files

- .agents/skills/failure-gate-core/SKILL.md (sole correction boundary).
- The complete original primary plan/specification, shared checks and actual dependency/deliverable evidence.
- .agents/skills/skill-install-confirmation/SKILL.md (read only; no widening via the unrelated historical exception).
