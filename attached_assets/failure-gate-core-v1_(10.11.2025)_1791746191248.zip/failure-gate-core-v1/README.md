# Failure Gate Core v1

A standalone canonical core-only Failure Gate definition. Canonical installation target: .agents/skills/failure-gate-core/SKILL.md. The ZIP preserves that target path. Full Failure Gate v4 is unchanged by this work.

## Status

- Authored at the canonical .agents path in this conversation's environment.
- NOT installed in Custom Skills Workbench; the connection is inspection-only for file edits.
- NOT published as a workspace skill or automatically available in future conversations.
- No native project tasks created, approvals manufactured, runtime installed, active contract/default changed, checks launched, stores initialized or cutover performed.
- Mechanical definition/front-matter/size/acceptance-item/archive readback performed here; independent file confirmation and actual host runtime proof are NOT_RUN.

## Included

The canonical skill; complete independent authoring specification and frozen candidate; paired installation and file-only confirmation plans; one same-batch alias/dependency payload; definition identity/readback metadata. The distribution ZIP is not a runtime evidence import or execution grant.

## Install and confirm

Use the complete install primary and dependent confirmation, created together through the actual permitted batch route with alias install-failure-gate-core-v1. Confirm complete persisted plans/dependency and delivered canonical file; never copy only the summary. The workbench's canonical installation rule names a creation route unavailable to this conversation. An available alternative can express the same joint alias/dependency shape, but was NOT silently substituted. An explicitly authorized equivalent route can be used for this pair without editing the general rule. Task creation, start approval, source delivery and confirmation remain distinct.

The install primary writes only the new canonical SKILL.md. The confirmer lists gaps before patching and repairs only that file, with the canonical greater-than-half rewrite escalation. Neither task implements or activates the Gate. Publishing for workspace-wide reuse is a separate action through the workspace Skills interface; this downloadable package alone does not publish it.

## Deliberately retained

Permanent local Task IDs, exact approval/plan/tier bindings, one tier, finite independent whole-entry supervision, owned-child/resource coordination, minimal durable raw evidence, current-snapshot final-writer completion, honest owner-directed closure, actual isolated restore/non-reuse and exact acknowledged recovery.

## Outside the Core contract

Ignores/catalogs, provenance/flakiness/auxiliary diagnostics, unrelated-process reclaim, portable evidence export/import, automatic progression/pruning, remote/distributed execution. These are not pending Core requirements. Full-v4 capabilities require separately approved adoption, not automatic dependency inheritance.
