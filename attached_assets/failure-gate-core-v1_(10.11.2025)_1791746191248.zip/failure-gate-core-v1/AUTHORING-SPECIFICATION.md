# Failure Gate Core v1 — definition specification

## Authorized outcome

Create a traditional standalone canonical core-only Failure Gate skill at .agents/skills/failure-gate-core/SKILL.md, version 1. The user approved the Core profile proposal and then instructed us to create the canonical definition. Full Failure Gate v4 is unchanged. This request does not implement/activate the described runtime, adopt Core as this project's governing profile, change a workspace default, execute the six-pair installation, or publish workspace-wide instructions.

## Portability and scope

The resulting file must be self-contained: no full-v4 normative dependency, particular app/framework/database/CLI/port/task service, fixed project identity, universal task count or advanced-feature setup prerequisite. Use only canonical .agents sources, not runtime mirrors. Preserve all retained outcomes below, with prospective project-specific installation methods generalized for any host. Preserve independently approved budgets and actual proofs: smaller scope cannot waive retained safety because the host lacks a provider.

## Scope: retained outcomes

| ID | Required outcome | Principal owner / proof gate |
|---|---|---|
| C01 | Transactional unique project-local IDs; committed IDs never reused; namespaces, tombstones, and prior committed identities preserved across restart/restore | 02 source; 03 live allocation; 05 restart/restore |
| C02 | One authoritative task record with exactly one active authorized registered tier; all others denied; terminal/suspended tasks cannot run | 02 model; 04 installed behavior |
| C03 | Exact task/plan/version/digest/tier-definition/parameter/policy/authorization bindings; run snapshots kept separate from authorization | 02 model; 04 decisions and runs |
| C04 | Authentic supported approval or owner-approved deterministic policy; current bound decisions and atomic audit; no self-approval or status/flag substitutes | 01 source discovery; 04 installed decision route |
| C05 | Coverage-preserving registered checks and separate bounded pre-activation planning guards; no invented tier names, arbitrary dispatch, or all-tier sweeps | 04 |
| C06 | Actual independently approved finite queue, input, step, startup, test/hook, teardown, termination, verification, capture, parent, and applicable attempt/resource bounds; retained consumption and no hidden renewal | 02 source; 03 first proof; 04/05 installed routes |
| C07 | Independent whole-entry supervisor and registration before user dispatch; bounded synchronous/async stalls and supervisor/owner loss | 02 source; 03 actual first proof |
| C08 | Exact owned-child tracking and safe bounded cancellation/termination; uncertainty retains exclusion; no unrelated listener killing or lease deletion | 02 source; 03/04/05 installed proof |
| C09 | Validated configuration and bounded reads; stable actual tested-content/environment identity; complete native reports/raw exits/signals; missing/skipped/truncated/late-zero results never pass | 03 capture; 04 installed adapters |
| C10 | Atomic task/operation single-flight, safe queued-request revalidation, cross-task resource exclusion and child-aware release | 02 primitives; 03 foundation proof; 04 integrated proof |
| C11 | Minimal durable decision/intent/start/finish/denial/uncertainty trail outside .local, one evidence index and bounded read-only lookup; logs distinguish intended from confirmed launches | 03 bootstrap evidence; 04 telemetry; 05 mode readers |
| C12 | Retain raw failures and owned repair obligations; no automatic ignores, provenance acceptance, flaky labels, or completion from a lucky retry; unresolved failures block validated completion | 04/05 |
| C13 | Current selected-tier post-edit evidence and effective final-writer coordination; actual installed-path race; stale/direct/wrong-task/incomplete results reject local validated completion | 05 |
| C14 | Explicit task-scoped owner-direction closure is separate from validation; preserve assessments/repairs, revoke local permission safely, and make all dependent readers distinguish the modes | 05 |
| C15 | Durable storage, safe restart, actual isolated host-format backup/restore, post-backup ID reconciliation and old-writer fencing; never restore production under this plan | 02 source; 05 actual drill |
| C16 | Separate exact bounded retained-error recovery and acknowledgement; no expiry/heartbeat-based unlock, history reset, terminal-ID reopening, or replacement while owned work is uncertain | 02 source; 03/05 installed proof |
| C17 | Preserve real independent callers, command coverage, reports and existing authority; they are not checked-task evidence; cooperative controls cannot attest arbitrary shell/editor/platform dispatch | 01 inventory; 04 compatibility; 05 writer coverage; 06 real callers |
| C18 | Full task payloads, genuine primary finalization, independently checked dependencies/delivery, duplicate/uncertain-write reconciliation, and independent post-repair acceptance before advancement | All six pairs |
| C19 | One separately authorized ordinary-route cutover after actual full retained-scope proof; no competing ordinary authorities, automatic merge, or platform-completion dependency | 06 |
| C20 | Explicitly authorized profile/version and source reconciliation; preserve historical eighteen-piece records and grants; changed governing inputs renew affected bindings, not unchanged evidence by rote | 01; final recheck at 06 |

One requirement-to-evidence matrix tracks these IDs, fixed expected outcomes,
actual proof references and verified/failed/blocked/justified-not-applicable
assessments. Do not create a second authoritative task registry or track every
programming choice. Source references support requirements; copied paragraphs,
counts, digests and an installer's success statement are not behavior proof.

## Removed or deferred from the initial Core profile

| Full-profile capability | Initial Core treatment |
|---|---|
| Automatic progression, callbacks, scheduler or polling | Excluded; resume on explicit invocation |
| Protected runtime reclaim of pre-existing/unrelated processes | Excluded; no such signals; conflicts report BLOCKED |
| Baseline catalog, ignore promotion and pre-existing-failure acceptance exceptions | Excluded from initial use; no ignores or ACCEPTABLE_WITH_IGNORED_FAILURES decisions |
| Flakiness/provenance automation, three-isolation-retry classification, earlier-snapshot comparisons and auxiliary diagnostic dispatch | Deferred; do not invoke or claim these capabilities |
| Portable evidence export/import and broad evidence-management UI | Deferred; local audit records, access controls, evidence index and bounded operational lookup retained |
| Automated pruning/rotation policy engine | Deferred; preserve necessary artifacts and permanent ID tombstones; bounded capture and storage-health admission still required |
| Distributed/remote workers or cross-clone coordination | Excluded; one verified local coordinator and approved local execution graph only |
| Per-choice method ledgers, coding diaries and repeated confirmation loops | Not required; retain material exception/amendment and actual acceptance evidence |

Owned-work termination under its original supervision grant is NOT runtime
reclaim and remains mandatory. A same-tier checked rerun after relevant edits is
NOT an auxiliary diagnostic capability; it remains possible under applicable
current authorization and actual limits. A passing retry cannot retrospectively
erase an earlier failure or establish pre-existing provenance.

Reclaim-dependent aliases/startup hooks must be identified. If any retained caller
depends on reclaim, safely remove that dependency through explicit approved scope
or block its integration/cutover. Missing providers cannot be called N/A while a
dependent caller remains. Do not modify Port Authority or other skills by implication.

These exclusions do not amend the installed Failure Gate v4 definition. Before
using this profile to govern execution, obtain and pin actual owner adoption of
the scoped contract and reconcile conflicting project instructions through their
authorized route. Do not claim an excluded full-v4 requirement has passed.
Previously active authority remains controlling until an authorized transition.



## Core definition refinements approved in this conversation

Name the new independent contract Failure Gate Core v1 (slug failure-gate-core). Prefer recommending it for ordinary new installations, without silently migrating an active contract or installing a workspace default. Excluded full-v4 features are outside the Core contract, not unfinished obligations or implied dependencies. Distinguish source/definition installation, actual host implementation, isolated fixtures, runtime acceptance, profile adoption, task approval, bootstrap permission, cutover and platform lifecycle. Advanced upgrades require actual authority, not automatic inheritance.

Use one tier per permanent local Task ID; one real transactional store, decision/run linkage, single-flight/resources, minimal durable trail, reliable current tested inputs/reports, effective final-writer protection, owner_direction versus validated mode, actual isolated restore/non-reuse, and separately acknowledged exact recovery. Preserve genuine independent callers. No catalog ignores, ACCEPTABLE_WITH_IGNORED_FAILURES, auxiliary diagnostics/flakiness/provenance/comparison dispatch, reclaim, portable export/import, automatic progression/pruning, or remote/distributed dispatch. Necessary checked same-tier reruns and original owned-work cleanup are retained and are not those excluded capabilities.

An earlier failing run needs resolution evidence; a lucky retry cannot erase it. Actual independent bounds, original consumed lineage and safe first-proof admission remain mandatory. Source-stage acceptance cannot satisfy actual runtime, installed writer-race, real restore or real-caller acceptance. Keep routine programming autonomous, without per-choice diaries or approvals. Bound native plan/dependency/delivery readbacks and duplicate/unknown-write reconciliation. Independent post-repair acceptance must be fresh, without recursive task creation. Do not claim tamper-proof shell control or platform integration.

## Frozen candidate contents

The complete candidate below is the exact definition to install. Confirmation must check it against the independent retained-scope specification above, not use the candidate's own assertions as sole proof. In-scope corrections are allowed only in the target SKILL.md.

~~~~markdown
---
name: failure-gate-core
description: >-
  Install, plan, operate, or audit Failure Gate Core v1: project-local Task IDs,
  one approved validation tier, bounded checked execution, durable evidence,
  current-snapshot completion, separate owner-directed closure, and safe recovery.
  Use for explicit Core/core-only Failure Gate requests or an authorized new Core
  installation. This standalone reduced contract excludes baseline ignores,
  provenance/flakiness diagnostics, runtime reclaim, portable export/import,
  automatic progression, pruning automation, and remote/distributed dispatch.
---

# Failure Gate Core v1

## 1. Purpose, scope and authority

Core is a standalone cooperative project-local validation contract, not a partial
installation of full Failure Gate v4. Its entire normative contract is this file.
Do not import full-v4 references, advanced requirements or examples as dependencies.
Use full v4 when its advanced capabilities are explicitly requested.

Separate definition installation, host implementation, adoption, task approval,
bootstrap permission and ordinary cutover. Writing/loading this skill establishes
none of the other five. Prefer Core for a proposed ordinary new installation;
never silently replace an active contract or change a workspace default.

The runner and local completion checker govern participating project-local routes.
They cannot force arbitrary shell/editor users, CI or Replit's Task Board to obey,
authenticate an adversarial agent who can edit tooling, or prove unobserved callers.
Project code/CLI must not invoke, proxy, depend on or import platform-managed
completion. Genuine Agent-native owner-directed closure is separate (§7).

Excluded capabilities are not unmet Core installation requirements:
- Catalog/baseline ignores, promotion and exception-based failure acceptance.
- Automated flakiness/provenance classification, isolation retries, earlier-snapshot
  comparison, and auxiliary diagnostic dispatch.
- Reclaim/signaling of pre-existing or unrelated runtime processes.
- Portable evidence export/import, distributed/remote execution or cross-clone control.
- Automatic progression/hooks/polling, automatic merge/deploy and automated pruning.

Do not use Core to silently waive a full-v4 obligation, accept old ignores, or supply
an excluded capability. Migration/extension requires explicit scope and policy
approval under prior governance, with affected bindings renewed. Never activate two
ordinary authorities. Preserve historical task records, grants, failures and evidence;
old grants are not new permission. No specific framework, runtime, store or companion
skill is required. Host-required planning and regression protections still apply.

## 2. Discover and install without borrowing authority

For **operate/audit**, inspect and use only real verified interfaces; do not implement
missing controls unasked. For **definition installation**, write only the authorized
definition; do not apply its runtime contract. For **host implementation**, discover:

- Project/root/namespace, canonical instructions and controlling contract/version.
- Actual validation commands, complete command graphs, configuration, native reports,
  plan/task format, existing callers, coverage and resource lifecycles.
- Transactional ID/task/run/audit store, decision/policy source and allocator history.
- Finite budget authority, independent supervisor, containment and capture transport.
- Effective accepted-state writers/isolation, completion/closure readers and recovery.

Keep canonical sources under `.agents` on hosts using it; never use `.local` mirrors
as authority or deliverables. Pin current applicable sources and separate prior
obligations, pre-install project observations and actual delivered implementation.
Reuse supported discoveries rather than restart inventories. Source changes invalidate
affected evidence, not every unrelated fact. Do not overwrite protected plans/history.

Record **ACTIVE**, **INACTIVE** or **UNKNOWN** governance from actual authority.
ACTIVE uses its real checked routes. Verified INACTIVE retains verified existing
host policy and equivalent finite supervision. UNKNOWN blocks dependent execution;
it does not prove inactivity. Explicit checked requests never fall back.

Use one tracked capability manifest/evidence index and one requirement-to-evidence
matrix. Record each required capability as present, missing or unavailable, with
actual interfaces, fixed outcomes, evidence and responsible next action. A filename,
README, passing mock or native task status cannot prove an installed capability.

Stage implementation explicitly:
1. **Discovery/inert source:** stage approved source/schema/test cases. If permission
   is inert-only, no imports, syntax checks, guards, package commands, tests or store use.
2. **Bootstrap proof:** obtain authentic exact bounded permission under prior
   governance and an independently safe carrier before executing first proof.
   Missing containment blocks even a hang test; mocks cannot authorize real dispatch.
3. **Integrated acceptance:** independently verify real checked routes, writers,
   closure/readers, accounting and an authorized isolated actual restore.
4. **Ordinary cutover:** require current independent pre-cutover acceptance and separate
   genuine transition approval; fence old authority, transition once and obtain fresh
   independent post-transition acceptance under specifically approved smoke scope.

An owner may approve a deterministic activation policy once for an exact scope/version
and coverage-selection rule. Discover/reuse an applicable approved policy; if absent,
prepare one for actual approval. Proposed policy is not active. Bootstrap permission
does not activate ordinary tasks. Missing retained capability blocks its dependent
claim; a correct denial proves denial behavior, not readiness of the missing route.

Within approved scope, choose ordinary programming methods without coding diaries,
per-choice approval or repetitive status narration. Renew authority only for material
scope, coverage, acceptance, policy or safety changes. At a boundary, continue feasible
nonconflicting authorized work and prepare the smallest exact missing integration,
review, recovery or permission proposal; do not create/start follow-ups automatically.

## 3. IDs, plans and the single tier

Allocate local IDs transactionally within a verified project namespace. A committed
ID is permanently non-reusable, including after deletion/cancellation/restore. Keep
namespace history and tombstones. A Replit/native task number, plan title or planning
label is not local authorization. Planning/bootstrap operations use their real
separate scoped identity, never a fabricated active task to bypass admission.

One authoritative task record has one active registered tier. Derive ALLOWED for
that tier and NOT ALLOWED for all others; newly added tiers default-deny. Suspended
or terminal tasks deny every tier. Do not maintain parallel editable allow/deny lists.

The record binds exact project/local ID, durable plan contents/version/digest,
registered tier/definition digest, permitted parameters, policy and authorization
versions, authentic decision reference, state and owned repair obligations. Each run
separately records actual tested contents/environment. Ordinary in-scope edits do
not renew approval, but invalidate affected run evidence.

Select the lightest registered tier whose actual complete coverage satisfies the task.
If uncertain, use the verified selection policy or block; never invent a tier/default.
Plan semantic fields must include local identity, single selected tier/why, exact
checked route, applicable limits, no-escalation rule and repair obligations. Preserve
host-required sections. If an ignore section is required, state:
“None authorized; Core does not accept ignored failures.” Keep task-local observations
separate from authorization; capture pre-edit observations only through an actually
approved bounded planning route when host policy requires them.

Before activation, run required plan guards through a separately approved bounded
draft capability. Guards never satisfy task completion. Validate exact plan/root/
namespace; reject traversal, escaping symlinks and another task's otherwise valid plan.

A trusted Replit approval event may supply the decision without an approver roster:
verify exactly what was approved and its local binding, not an invented actor ID.
Other hosts may use actual authorized human decisions. A preapproved deterministic
policy may issue a separately persisted decision for each matching plan. Unknown or
unmatched plans require actual approval. Pin decision/policy contents and provenance;
mutable agent-written approved flags, Active/Ready/Done, command approval, merge,
environment variables or a supplied task number are insufficient.

Atomically commit activation/amendment with its audit, recording derived tier status.
Serialize against launches/runs. Plan/tier/definition/parameter/policy changes require
fresh matching decisions; never carry old authority forward or self-approve a change.
Keep the prior policy controlling until authorized transition; reject unknown commits
pending reconciliation. Rejection cannot clear an independent suspension.

## 4. Checked execution and finite supervision

Provide actual checked activation and selected-tier execution under the same local
ID/approved plan. A Draft/Plan or platform Active state alone does not activate it.
Run the checked tier after relevant edits; reruns use current authorization and real
per-run limits. Do not call a direct command a checked run after it finishes.

Before every cooperative launch and queued dispatch, verify:
- Current identity, plan/decision/tier/policy versions, state, applicable decision
  expiry/revocation and permitted parameters from the actual authoritative sources.
- Actual registered argv/steps/config branches, aliases/pre/post hooks, test discovery,
  nested scripts, workers and selectors; deny unknown scope or coverage reduction.
- Required environment/configuration from verified sources, including supported port/
  resource reservation where needed; no invented defaults, secrets in logs or shell
  interpolation of untrusted strings.
- Independent approved finite bounds and remaining original allowance for input/
  configuration reads, queue, steps, startup, tests AND hooks, teardown, cancellation,
  termination/verification, evidence capture, parent lifetime and applicable attempts/
  resources. Verify installed runtime support and safe units/ranges/aggregates.
- Healthy required journal/capture/supervision, atomic task/operation single-flight
  and applicable cross-task resource leases; duplicate requests return/reject or queue
  under a finite policy, never launch a second top-level run.

Missing, zero, negative, disabled, nonfinite, overflowing or caller-enlarged limits
deny dispatch. For Node timer milliseconds require integer 1..2147483647; other hosts
use verified safe representations. Record effective values/source/version, not merely
a timeout option's presence. Reserve consumption atomically across children and
purposes. Started failed/cancelled attempts consume allowance; release unstarted
reservations only after confirmed non-launch/reconciliation. Restart/new wrapper/run
ID or purpose labels cannot renew original accounting/deadlines. Narrowed inherited
limits stay narrowed. Required same-tier reruns remain distinct from excluded
auxiliary diagnostics and are never permission to retry until lucky.

Use verified monotonic elapsed time with protected restart lineage. Reserve finite
cleanup/capture time; insufficient remainder means no new work. Admission expiry
does not orphan already authorized owned work and grants no new launch or reclaim.

Require independent whole-entry outer supervision outside the supervised event loop,
registration before user dispatch and bounded preflight/capture. A test/hook timer,
shell-client timeout or resource lease alone is insufficient. Track exact owned
process incarnations and approved descendants; process names/ports/PIDs alone are
not ownership. If permitted children can escape observable groups, require stronger
verified containment or block that graph. Remote/watch work cannot masquerade as
finite local validation; server fixtures require bounded readiness/use/owned teardown.

On deadline, cancellation, owner/watchdog loss or post-spawn journal failure, stop
new dispatch and attempt bounded exact owned-tree cleanup under its original grant,
even when journal writes fail. Newly observed owned descendants receive applicable
termination; verify stopped/quarantined status. Keep slot/resource exclusion and
partial evidence while lifecycle is uncertain. Timeout, heartbeat expiry, child exit
or local quiescence alone never authorizes replacement. Do not signal unrelated
listeners, unlink leases or insert healthy recovery flags to continue.

Record actual tested-content/environment identity, not just HEAD of a dirty tree.
Prevent mutation during validation or detect and reject it. Native reports must
account for each required step/discovery count and actual exit/signal. Capture combined
stdout/stderr with streaming/spooling byte bounds. Truncation, missing reports,
unexpected zero-discovery, required skips, cancellation, masked timeout, late zero
after the execution deadline, malformed truthy stop/storage acknowledgements or
unconfirmed capture/storage cannot become PASS.

Preserve genuinely independent local/platform/CI callers under their actual authority,
commands, reports, coverage and existing safety policy without mandatory task metadata.
Their local finite launches still need verified equivalent bounds; unavailable
required coverage/readiness is explicit, not an exemption. Do not trigger extra CI/
platform checks, change dispatch or migrate independent callers unasked. Task-agent
delegated/background work is not independent simply because it bypasses the runner.
Independent/direct outcomes cannot satisfy checked task evidence.

## 5. Minimal durable evidence and investigation

Maintain durable decision/intent/confirmed-start/finish/denial/uncertainty records
outside `.local`, indexed from the manifest. Bind actual task/operation/run, purpose,
plan/authorization/policy/tier versions, initiator/parent, transitive scope, snapshot/
environment, effective limits/consumption, raw results, native artifacts and cleanup/
capture acknowledgements. Distinguish attempted from confirmed launch and missing/
corrupt/unavailable/unknown evidence. Atomically couple managed mutations to audit;
required logging/storage failures block affected dispatch/acceptance.

Provide bounded read-only lookup for task/run/overlap/retained incidents and basic
state/evidence health needed for safe admission. On overlap/unauthorized-run questions,
find indexed original records automatically; report actual launches, timing, supported
causes and unobservable coverage. Do not run tests, clear leases, change policy or kill
processes to investigate. Absence of events is not proof of no unmanaged execution.

Keep necessary supporting artifacts, access controls, secret-safe capture and permanent
ID history. Core requires no broad evidence-management UI, portable export/import,
rotating catalog or pruning engine. Exhausted storage blocks dependent recording, not
permission to delete evidence/tombstones. Copied logs do not acquire independent or
tamper-proof authority.

## 6. Failures and validated completion

Core authorizes no ignored failures and no ACCEPTABLE_WITH_IGNORED_FAILURES result.
Retain each raw failure and owned repair. Verify/fix owned obligations within task
scope; skipping/deleting/renaming/filtering a test does not prove repair. Do not fix
unrelated code automatically or label uncertain ownership as proven task causation.

Investigate through authorized source/record reads and applicable checked same-tier
runs after edits. Prior required-run failures need explicit resolution evidence or
remain unresolved; a lucky retry cannot erase them or prove pre-existing provenance.
No automatic three-retry rule, baseline promotion or auxiliary diagnostic dispatch.
Unresolved required failures block validated completion even if considered historical.

The actual local checker evaluates complete current selected-tier post-edit evidence,
exact task/plan/decision/run bindings, owned repairs and actual applicable inputs.
Coordinate final input verification, evidence assessment and terminal write with
effective writer/authorization isolation so edits/transitions cannot intervene.
Demonstrate an installed-path competing-writer race before ordinary activation;
an isolated lock primitive is not proof. Uncontrolled accepted-state writers block
the dependent validated-completion claim.

Keep raw status separate from assessment:
- **PASS:** complete applicable current required evidence succeeds; repairs fulfilled.
- **FAIL:** a required product check/repair fails.
- **BLOCKED:** required authority/capability/environment/evidence is unavailable.
- **INCOMPLETE:** unfinished, stale, skipped, missing or untrustworthy execution/results.

Agent summaries, direct passes, fixture success, prior snapshots, platform lifecycle
or manually supplied PASS labels cannot authorize local validated completion. Required
external acceptance that is unavailable remains blocked; never impersonate it.
Atomically record validated terminal mode/evidence/audit and revoke active permission,
after safe owned-run handling. Failure/cancellation can safely release permission
without a passing test but retain history/repairs; never reopen terminal IDs.

## 7. Owner-directed closure remains separate

An authentic owner instruction to close one resolvable task is sufficient scoped
direction; require neither passing validation nor a second review/activation merely
for closure. Resolve ambiguous identity only when necessary. Retain actual decision
contents/reference, task/project/version, reason (or “owner direction”), current
assessment/not-run and unresolved checks/repairs. Never invent a message ID, actor
roster, crypto identity or an automatic waiver from status/silence/frustration.

Through a real local route, coordinate active/uncertain owned work safely and atomically
bind owner direction, terminal permission release, audit and unambiguous
`completionMode: owner_direction` (or linked equivalent). Normal accepted completion
uses `validated`. If readers cannot distinguish modes, local closure remains blocked;
do not write a bare completed flag. No passing-run snapshot or code-writer proof is
required solely to disclaim validation, but actual lifecycle safety remains mandatory.

Keep validation/repairs unchanged. Readers, reports and dependencies must not treat
administrative closure as successful validation/delivery. Repeat the same decision
idempotently; reconcile intervening material changes and unknown commits. Say:
**“Closed by owner direction—not validation passed.”**

A genuinely available Agent-native platform closure may proceed under explicit owner
direction and actual platform permissions even if local closure is unavailable.
Never proxy it through project code/CLI or invent an interface. Read back local and
platform writes independently; report partial outcomes and actual cleanup/state.
No cross-system transaction, merge/deploy, standing auto-close or follow-up task is
implied. Owner closure does not accept a failed implementation or satisfy a runtime
installation prerequisite.

## 8. Persistence, isolated restore and exact recovery

Commit identities, task decisions, runs, audit, consumption and terminal modes durably
through appropriate transactional host storage. Restart cannot regenerate IDs,
forget consumed authority, resurrect terminal tasks or infer stopped work from age.
Resolve idempotent/unknown writes from authoritative records before repeating.

Before readiness, obtain actual safe drill permission and prove real host-format
backup/restore in isolation: preserve namespace/committed IDs/tombstones, reconcile
IDs committed after the backup against retained authoritative high-water/history,
fence old writers, retain consumption/uncertainty and prevent stale approvals from
reactivating. Missing complete reconciliation blocks allocation; do not reuse IDs.
A mocked restore or production restore does not meet this drill.

Retained-error recovery needs authentic separately scoped finite permission tied to
original incident/task/operation/version/owned incarnations and current constraints.
Reconcile contenders and ambiguous claim/write outcomes before action; require actual
durable acknowledgement before releasing authoritative exclusion. True, unfinalized
or missing-field recovery-required leases remain excluded even after local quiescence.
Only a compatible healthy finalized no-recovery-required disposition AND known
quiescence permits ordinary documented recovery; a missing boolean/typed equivalent
is not false. No blind signal/replay, age-based unlink, counter reset, false
insertion, history deletion or terminal-ID reopening.

## 9. Independent acceptance and truthful reports

Before installation execution, freeze retained outcomes and intended evidence; resolve
method details against actual delivery without weakening criteria. Preserve complete
primary/verifier plans, actual finalized revisions/dependencies and snapshot-bound
delivery. Audit first, publish gaps before scoped repair, invalidate affected evidence
and obtain fresh independent post-repair acceptance. Installer/repair-author assertions
or native Ready/Done are not independent acceptance. Missing review route blocks that
claim; prepare an exact proposal, not recursive task creation.

If host-task planning is actually authorized, reconcile matching project/primary/
finalized-plan/scope records and uncertain writes before creating anything. Verify
committed primary finalization, complete persisted primary/verifier readbacks, actual
dependencies and delivered inputs through supported interfaces; recheck executable
payloads at linkage, execution and report acceptance. Do not guess task IDs, infer
commit from a timeout/status/title, replace a running verifier, reopen terminal work
or silently renew protected plans. Definition installation and runtime application
need their independently applicable scopes; an installation task cannot approve itself.

Acceptance must cover:
| Boundary | Required affirmative / negative proof |
|---|---|
| IDs/storage | Real concurrent unique commits, audit rollback/idempotency, restart, tombstones and non-reuse |
| Approval/tier | Actual trusted decision/coverage; forged, stale, wrong-project/plan/tier, suspended/terminal and expanded graphs deny |
| Budgets/supervisor | Real finite settings/remaining lineage; async/sync/hook/setup stalls, owner/watchdog loss, late-zero/overflow and failed registration |
| Coordination/children | Installed single-flight/queue/resource races and known owned-tree termination; uncertain work retains exclusion |
| Inputs/reports | Actual contents/environment/native reports; malformed config/paths, mutation, skips/missing evidence and bad acknowledgements reject |
| Completion/writers | Current checked results and fulfilled repairs; actual installed final-writer race, stale/direct/wrong-task evidence rejection |
| Closure/readers | Authentic isolated owner direction, unchanged failed/not-run assessment, safe revoked permission and mode-aware prerequisites |
| Recovery/restore | Actual isolated host-format restore, post-backup identities, old-writer fencing and acknowledged exact retained-error recovery |
| Callers/cutover | Real required local callers under their own authority, preserved coverage, singular authorized transition and fresh acceptance |

Use isolated controlled negative cases; raw nonzero/timeout may be the expected denial
or injected outcome, not successful ordinary validation. Never trigger unauthorized
tiers/remote jobs or signal live unrelated processes to prove denial. Each enabled
control/required local caller needs two consecutive genuinely authorized real route
runs within applicable limits; fixtures alone cannot establish readiness. Missing
required permission, real proof or remaining allowance remains BLOCKED/NOT_RUN.

Report definition/source, implementation, isolated tests, actual runtime readiness
and platform lifecycle separately. State real local task/tier/run IDs, tested inputs,
raw outcomes, assessment, completion mode/decision, unresolved obligations, limitations
and authority actually obtained. Say “Failure Gate Core v1 verified” only when every
applicable retained outcome has current independent evidence; never claim full v4
compliance. The number of installation tasks/pairs is host-dependent, not a Core
minimum or maximum.

~~~~
