[REGRESSION-GUARD] Classification: compatibility-contract, security-privacy, data-integrity, concurrency-lifecycle. Guard: covered — scripts/test/failure-gate-core6-source.test.mjs.

# Failure Gate v4-derived Core profile — six-pair installation proposal

<!-- regression-guard: required -->

## Decision and status

Target: Custom Skills Workbench, repository
https://github.com/makerdan/Custom-Skills-Workbench.
Project snapshot inspected for this proposal:
`3473b2c76f0f450fbbc9a0b73efef80704507e45`.

Proposal identity: `Custom-Skills-Workbench/failure-gate-core6/proposal-v1`.
This is a new candidate specification, not a replacement of the active
`failure-gate-v4/reimplementation-18-piece` generation.

Six implementation/verifier pairs means twelve base task payloads. The labels
`CORE6-01-I` through `CORE6-06-V` are planning labels, NOT platform task numbers
and NOT allocated Failure Gate IDs. Actual IDs, dependencies, approvals, selected
tiers, finite budget values, grants, and runtime results remain unassigned.

The user's instruction to write this proposal authorizes document authorship
only. It does not adopt a reduced governing contract, replace existing plans,
create tasks, approve task execution, renew budgets, migrate data, run validation,
recover leases, signal processes, enable controls, cut over, merge, or publish.

**Success claim:** independently verified installation of the explicitly adopted
Core profile. Never claim complete compliance with the unchanged full v4 contract.

## Why six pairs

The old eighteen-piece specification separates capabilities more finely than
this reduced installation needs. This proposal combines related implementation
and verification work, removes advanced capabilities from the initial profile,
and preserves three distinct boundaries: source preparation, first actual
bootstrap runtime proof, and final ordinary-route acceptance/cutover.

The retained requirements below are the acceptance standard. Verification methods
may adapt to actual delivered wiring, but the author cannot weaken criteria to
match what was built. Six pairs is not a guaranteed maximum: real missing
capabilities or an unavailable independent post-repair review route can require
separately authorized additional work.

## Scope: retained outcomes

| ID | Required outcome | Principal owner / proof gate |
|---|---|---|
| C01 | Transactional unique project-local IDs; committed IDs never reused; namespaces, tombstones, and prior committed identities preserved across restart/restore | 02 source; 03 live allocation; 05 restart/restore |
| C02 | One authoritative task record with exactly one active authorized registered tier; all others denied; terminal/suspended tasks cannot run | 02 model; 04 installed behavior |
| C03 | Exact task/plan/version/digest/tier-definition/parameter/policy/authorization bindings; run snapshots kept separate from authorization | 02 model; 04 decisions and runs |
| C04 | Authentic supported approval or owner-approved deterministic policy; current bound decisions and atomic audit; no self-approval or status/flag substitutes | 01 source discovery; 04 installed decision route |
| C05 | Coverage-preserving registered checks and separate bounded pre-activation planning guards; no invented tier names, arbitrary dispatch, or all-tier sweeps | 04 |
| C06 | Actual independently approved finite queue, input, step, startup, test/hook, teardown, termination, verification, capture, parent, and applicable attempt/resource bounds; retained consumption and no hidden renewal | 02 source; 03 first proof; 04/05 installed routes |
| C07 | Independent whole-entry supervisor and registration before user dispatch; bounded synchronous/async stalls and supervisor/owner loss | 02 source; 03 actual first proof |
| C08 | Exact owned-child tracking and safe bounded cancellation/termination; uncertainty retains exclusion; no unrelated listener killing or lease deletion | 02 source; 03/04/05 installed proof |
| C09 | Validated configuration and bounded reads; stable actual tested-content/environment identity; complete native reports/raw exits/signals; missing/skipped/truncated/late-zero results never pass | 03 capture; 04 installed adapters |
| C10 | Atomic task/operation single-flight, safe queued-request revalidation, cross-task resource exclusion and child-aware release | 02 primitives; 03 foundation proof; 04 integrated proof |
| C11 | Minimal durable decision/intent/start/finish/denial/uncertainty trail outside .local, one evidence index and bounded read-only lookup; logs distinguish intended from confirmed launches | 03 bootstrap evidence; 04 telemetry; 05 mode readers |
| C12 | Retain raw failures and owned repair obligations; no automatic ignores, provenance acceptance, flaky labels, or completion from a lucky retry; unresolved failures block validated completion | 04/05 |
| C13 | Current selected-tier post-edit evidence and effective final-writer coordination; actual installed-path race; stale/direct/wrong-task/incomplete results reject local validated completion | 05 |
| C14 | Explicit task-scoped owner-direction closure is separate from validation; preserve assessments/repairs, revoke local permission safely, and make all dependent readers distinguish the modes | 05 |
| C15 | Durable storage, safe restart, actual isolated host-format backup/restore, post-backup ID reconciliation and old-writer fencing; never restore production under this plan | 02 source; 05 actual drill |
| C16 | Separate exact bounded retained-error recovery and acknowledgement; no expiry/heartbeat-based unlock, history reset, terminal-ID reopening, or replacement while owned work is uncertain | 02 source; 03/05 installed proof |
| C17 | Preserve real independent callers, command coverage, reports and existing authority; they are not checked-task evidence; cooperative controls cannot attest arbitrary shell/editor/platform dispatch | 01 inventory; 04 compatibility; 05 writer coverage; 06 real callers |
| C18 | Full task payloads, genuine primary finalization, independently checked dependencies/delivery, duplicate/uncertain-write reconciliation, and independent post-repair acceptance before advancement | All six pairs |
| C19 | One separately authorized ordinary-route cutover after actual full retained-scope proof; no competing ordinary authorities, automatic merge, or platform-completion dependency | 06 |
| C20 | Explicitly authorized profile/version and source reconciliation; preserve historical eighteen-piece records and grants; changed governing inputs renew affected bindings, not unchanged evidence by rote | 01; final recheck at 06 |

One requirement-to-evidence matrix tracks these IDs, fixed expected outcomes,
actual proof references and verified/failed/blocked/justified-not-applicable
assessments. Do not create a second authoritative task registry or track every
programming choice. Source references support requirements; copied paragraphs,
counts, digests and an installer's success statement are not behavior proof.

## Removed or deferred from the initial Core profile

| Full-profile capability | Initial Core treatment |
|---|---|
| Automatic progression, callbacks, scheduler or polling | Excluded; resume on explicit invocation |
| Protected runtime reclaim of pre-existing/unrelated processes | Excluded; no such signals; conflicts report BLOCKED |
| Baseline catalog, ignore promotion and pre-existing-failure acceptance exceptions | Excluded from initial use; no ignores or ACCEPTABLE_WITH_IGNORED_FAILURES decisions |
| Flakiness/provenance automation, three-isolation-retry classification, earlier-snapshot comparisons and auxiliary diagnostic dispatch | Deferred; do not invoke or claim these capabilities |
| Portable evidence export/import and broad evidence-management UI | Deferred; local audit records, access controls, evidence index and bounded operational lookup retained |
| Automated pruning/rotation policy engine | Deferred; preserve necessary artifacts and permanent ID tombstones; bounded capture and storage-health admission still required |
| Distributed/remote workers or cross-clone coordination | Excluded; one verified local coordinator and approved local execution graph only |
| Per-choice method ledgers, coding diaries and repeated confirmation loops | Not required; retain material exception/amendment and actual acceptance evidence |

Owned-work termination under its original supervision grant is NOT runtime
reclaim and remains mandatory. A same-tier checked rerun after relevant edits is
NOT an auxiliary diagnostic capability; it remains possible under applicable
current authorization and actual limits. A passing retry cannot retrospectively
erase an earlier failure or establish pre-existing provenance.

Reclaim-dependent aliases/startup hooks must be identified. If any retained caller
depends on reclaim, safely remove that dependency through explicit approved scope
or block its integration/cutover. Missing providers cannot be called N/A while a
dependent caller remains. Do not modify Port Authority or other skills by implication.

These exclusions do not amend the installed Failure Gate v4 definition. Before
using this profile to govern execution, obtain and pin actual owner adoption of
the scoped contract and reconcile conflicting project instructions through their
authorized route. Do not claim an excluded full-v4 requirement has passed.
Previously active authority remains controlling until an authorized transition.

## Six ordered pairs

| Pair | Implementation | Independent verification and scoped repair | Declared stage |
|---|---|---|---|
| 01 | Reconcile existing discovery and propose/adopt exact scope through the real owner route | Verify current source/host mappings, exclusions, approval claims and fixed coverage | Discovery/source proposal |
| 02 | Stage IDs, durable coordinator, budgets, single-flight, supervision and recovery primitives | Inspect actual complete source and deny paths; carry runtime proof to 03/05 | Inert source |
| 03 | Establish safely admitted first bootstrap proof | Independently prove real local coordinator, bounds, containment and retained evidence | Bootstrap runtime only |
| 04 | Integrate tier registry, approvals, checked execution, input/result adapters and telemetry | Prove installed positive/negative/concurrency/compatibility behavior | Bootstrap integration; no ordinary cutover |
| 05 | Integrate validated completion, owner closure, restart/restore and exact recovery | Prove live writer race, mode separation, actual isolated restoration and non-reuse | Separately bounded bootstrap/recovery |
| 06 | Resolve retained-scope gaps, prove real callers and prepare the singular cutover | Fresh whole-profile assessment; final independent acceptance and authorized transition | Ordinary-route acceptance/cutover |

Dependencies are semantic until actual task refs exist:
`01-I -> 01-V -> 02-I -> 02-V -> 03-I -> 03-V -> 04-I -> 04-V -> 05-I -> 05-V -> 06-I -> 06-V`.
Acceptance, actual delivered successor inputs and new applicable scope/authority
must exist before advancing. A dependency label, Ready/Done, merge, source hash,
or owner administrative closure alone does not establish them.

Pair 06-I stops at pre-cutover preparation. Pair 06-V first obtains independent
current pre-cutover acceptance, then requires the genuine separately scoped
cutover decision before performing any ordinary-authority transition. Fresh
independent post-transition acceptance is required after its actual smoke proof;
the transition author cannot self-accept. If the independent route or permission
is absent, the pair remains pending at that boundary without ordinary activation.

The complete twelve task files in `tasks/` include their shared constraints.
Use those full payloads, not this table or a file link alone, if native tasks are
later separately authorized. At most one unfinished pair is current; leave later
pairs as repository backlog. No hook or automatic successor creation is authorized.

## Existing work and source reconciliation

Reuse independently substantiated facts and repairs from the current discovery
chain, including #158/#160/#161, only for their actual reviewed snapshots.
Those are observed historical platform refs, not new plan labels or local IDs.
The latest inspected independent assessment reports current-source acceptance
BLOCKED; do not inherit acceptance from its completed native lifecycle.

Pair 01 compares the controlling current `.agents` sources to that review,
records the affected submission-order/profile requirements and authentic authority,
and renews only dependent matrices/readbacks. Preserve unaffected supported
observations, original reports and the old detailed ledger. Do not restart every
inventory, refresh hashes to hide drift, reopen old tasks, zero an allocator, or
carry grants/budget consumption into this new operation as fresh permission.

Potential tracked project destination if installation is later authorized:
`docs/validation/failure-gate-core6/`, with twelve complete proposed task payloads
under the established `docs/validation/task-plans/` convention. These are proposed
destinations, not files installed in the project by this document.

## Execution and evidence rules

No actual command, tier, grant or finite budget value is selected in this
proposal. Pair 01 discovers real command graphs and sources; Pair 02 authors
inert checks; Pair 03 requires actual approval, effective finite values and safe
independent containment before any executable proof. UNKNOWN governance blocks
dependent execution, not honest drafting or separately authorized inert source.

For each actual run retain: local task or approved bootstrap operation identity;
complete plan/version; decision/source and policy versions; registered command
graph and tier definition; actual tested snapshot/environment; selected/effective
limits, consumed/remaining allowance and cleanup reserve; intent versus confirmed
launch; raw per-step status/signal and native reports; owned-tree termination,
capture/storage acknowledgements; uncertain outcomes and retained exclusion.
Use bounded collection and no secrets. Tests, fixtures and actual host readiness
are separate claims.

Both positive and negative acceptance cases have fixed expectations before
execution. A correctly denied request passes its denial criterion, not an
implementation requirement to make a missing capability work. Expected injected
failure preserves raw nonzero/timeout results. Actual containment failure,
missing required live proof, unknown accounting or absent independent acceptance
blocks the dependent claim.

Every verifier audits complete delivered inputs first, publishes material gaps
before repairing, repairs only its approved scope, invalidates affected evidence,
renews applicable proof and obtains fresh independent post-repair acceptance.
No arbitrary extra tests, tier escalation, budget renewal, unrelated bug fixes,
recursive verifier task creation, fabricated provider or self-approval.

An actual independently approved budget binds bootstrap runs, selected-tier
reruns, recovery and caller exercises separately as applicable. New wrapper/run
IDs, purpose changes, restart or restoration cannot reset consumed authority.
An exhausted budget or missing containment produces an exact scoped proposal,
not a guessed timeout, lock deletion or unmanaged experiment.

## Minimal deliverables

1. One installation manifest/index: source/profile versions, capability mapping,
   current pair/task refs, handoff bindings, authority locators and raw evidence locations.
2. One requirement-to-evidence matrix for C01-C20, with per-case expectations and
   snapshot/method bindings. Shared evidence can support multiple mapped criteria.
3. Six verifier acceptance reports, one per pair; installer handoff fields live in
   the manifest rather than duplicating another report for every pair.
4. The actual runtime implementation, storage schema, approved policy/registry,
   focused regression sources, and original raw records required for the retained scope.

No paragraph-by-paragraph replacement of the historical 1,961-unit ledger is
required. Preserve it as history; reconcile retained requirement coverage without
silently dropping applicable retained conjuncts or live acceptance cases.

## Pre-existing failures to ignore

None authorized. No baseline-ignore capability is included in initial Core.
Preserve known historical failures/repairs; classify unproven provenance as
unresolved. Missing required reports, failed retained checks, unsafe lifecycle or
stale proof cannot become a validated pass.

## Validation

This proposal is document authorship and source inspection only. No tests,
guards, imports, syntax/type/build checks, package commands, CLI/store operations,
runtime experiments, task writes or activation ran. Named regression paths are
prospective deliverables, not existing or executed tests. Each future task must
resolve its exact approved execution route and effective limits before dispatch.
Source acceptance at 01/02 does not satisfy runtime proof at 03/04/05/06.

## Regression Guard

**Covers:** Scope reduction accidentally removes permanent Task IDs, weakens retained approval/containment/completion controls, inherits old acceptance, or presents the scoped proposal as full v4 implementation.
**Test location:** scripts/test/failure-gate-core6-source.test.mjs — prospective inert source authored in Pair 01; executable proof only under actual later authorization.
**What it checks:** Retained C01-C20 mappings and exclusions; complete twelve payloads and six-stage ordering; no local IDs/grants invented; frozen acceptance criteria; old history preserved; no source/runtime/cutover conflation or full-v4 PASS claim.

## Relevant files

- Canonical `.agents/skills/failure-gate-v4/SKILL.md` and applicable `reference/` closure.
- Canonical `.agents/skills/paired-task-orchestration/SKILL.md` and `references/series-state-and-handoff.md`.
- Canonical `.agents/skills/skill-application-router/` handoff/delivery requirements.
- Canonical `.agents/skills/regression-guard/SKILL.md` and current `replit.md`.
- Existing `docs/validation/failure-gate-v4-task-series.md`, checkpoint and reimplementation manifest.
- Existing Piece 01 independent assessment and source/native readback evidence.
- This proposal, complete `tasks/` payloads and `source-readback.txt`.
