[REGRESSION-GUARD] Classification: compatibility-contract, security-privacy, data-integrity, concurrency-lifecycle. Guard: covered — scripts/test/failure-gate-core6-source.test.mjs.

# Failure Gate v4-derived Core profile — six-pair installation proposal

<!-- regression-guard: required -->

## Decision and status

Target: Custom Skills Workbench, repository
https://github.com/makerdan/Custom-Skills-Workbench.
Project snapshot inspected for this proposal:
`3473b2c76f0f450fbbc9a0b73efef80704507e45`.

Proposal identity: `Custom-Skills-Workbench/failure-gate-core6/proposal-v1`.
This is a new candidate specification, not a replacement of the active
`failure-gate-v4/reimplementation-18-piece` generation.

Six implementation/verifier pairs means twelve base task payloads. The labels
`CORE6-01-I` through `CORE6-06-V` are planning labels, NOT platform task numbers
and NOT allocated Failure Gate IDs. Actual IDs, dependencies, approvals, selected
tiers, finite budget values, grants, and runtime results remain unassigned.

The user's instruction to write this proposal authorizes document authorship
only. It does not adopt a reduced governing contract, replace existing plans,
create tasks, approve task execution, renew budgets, migrate data, run validation,
recover leases, signal processes, enable controls, cut over, merge, or publish.

**Success claim:** independently verified installation of the explicitly adopted
Core profile. Never claim complete compliance with the unchanged full v4 contract.

## Why six pairs

The old eighteen-piece specification separates capabilities more finely than
this reduced installation needs. This proposal combines related implementation
and verification work, removes advanced capabilities from the initial profile,
and preserves three distinct boundaries: source preparation, first actual
bootstrap runtime proof, and final ordinary-route acceptance/cutover.

The retained requirements below are the acceptance standard. Verification methods
may adapt to actual delivered wiring, but the author cannot weaken criteria to
match what was built. Six pairs is not a guaranteed maximum: real missing
capabilities or an unavailable independent post-repair review route can require
separately authorized additional work.

## Scope: retained outcomes

| ID | Required outcome | Principal owner / proof gate |
|---|---|---|
| C01 | Transactional unique project-local IDs; committed IDs never reused; namespaces, tombstones, and prior committed identities preserved across restart/restore | 02 source; 03 live allocation; 05 restart/restore |
| C02 | One authoritative task record with exactly one active authorized registered tier; all others denied; terminal/suspended tasks cannot run | 02 model; 04 installed behavior |
| C03 | Exact task/plan/version/digest/tier-definition/parameter/policy/authorization bindings; run snapshots kept separate from authorization | 02 model; 04 decisions and runs |
| C04 | Authentic supported approval or owner-approved deterministic policy; current bound decisions and atomic audit; no self-approval or status/flag substitutes | 01 source discovery; 04 installed decision route |
| C05 | Coverage-preserving registered checks and separate bounded pre-activation planning guards; no invented tier names, arbitrary dispatch, or all-tier sweeps | 04 |
| C06 | Actual independently approved finite queue, input, step, startup, test/hook, teardown, termination, verification, capture, parent, and applicable attempt/resource bounds; retained consumption and no hidden renewal | 02 source; 03 first proof; 04/05 installed routes |
| C07 | Independent whole-entry supervisor and registration before user dispatch; bounded synchronous/async stalls and supervisor/owner loss | 02 source; 03 actual first proof |
| C08 | Exact owned-child tracking and safe bounded cancellation/termination; uncertainty retains exclusion; no unrelated listener killing or lease deletion | 02 source; 03/04/05 installed proof |
| C09 | Validated configuration and bounded reads; stable actual tested-content/environment identity; complete native reports/raw exits/signals; missing/skipped/truncated/late-zero results never pass | 03 capture; 04 installed adapters |
| C10 | Atomic task/operation single-flight, safe queued-request revalidation, cross-task resource exclusion and child-aware release | 02 primitives; 03 foundation proof; 04 integrated proof |
| C11 | Minimal durable decision/intent/start/finish/denial/uncertainty trail outside .local, one evidence index and bounded read-only lookup; logs distinguish intended from confirmed launches | 03 bootstrap evidence; 04 telemetry; 05 mode readers |
| C12 | Retain raw failures and owned repair obligations; no automatic ignores, provenance acceptance, flaky labels, or completion from a lucky retry; unresolved failures block validated completion | 04/05 |
| C13 | Current selected-tier post-edit evidence and effective final-writer coordination; actual installed-path race; stale/direct/wrong-task/incomplete results reject local validated completion | 05 |
| C14 | Explicit task-scoped owner-direction closure is separate from validation; preserve assessments/repairs, revoke local permission safely, and make all dependent readers distinguish the modes | 05 |
| C15 | Durable storage, safe restart, actual isolated host-format backup/restore, post-backup ID reconciliation and old-writer fencing; never restore production under this plan | 02 source; 05 actual drill |
| C16 | Separate exact bounded retained-error recovery and acknowledgement; no expiry/heartbeat-based unlock, history reset, terminal-ID reopening, or replacement while owned work is uncertain | 02 source; 03/05 installed proof |
| C17 | Preserve real independent callers, command coverage, reports and existing authority; they are not checked-task evidence; cooperative controls cannot attest arbitrary shell/editor/platform dispatch | 01 inventory; 04 compatibility; 05 writer coverage; 06 real callers |
| C18 | Full task payloads, genuine primary finalization, independently checked dependencies/delivery, duplicate/uncertain-write reconciliation, and independent post-repair acceptance before advancement | All six pairs |
| C19 | One separately authorized ordinary-route cutover after actual full retained-scope proof; no competing ordinary authorities, automatic merge, or platform-completion dependency | 06 |
| C20 | Explicitly authorized profile/version and source reconciliation; preserve historical eighteen-piece records and grants; changed governing inputs renew affected bindings, not unchanged evidence by rote | 01; final recheck at 06 |

One requirement-to-evidence matrix tracks these IDs, fixed expected outcomes,
actual proof references and verified/failed/blocked/justified-not-applicable
assessments. Do not create a second authoritative task registry or track every
programming choice. Source references support requirements; copied paragraphs,
counts, digests and an installer's success statement are not behavior proof.

## Removed or deferred from the initial Core profile

| Full-profile capability | Initial Core treatment |
|---|---|
| Automatic progression, callbacks, scheduler or polling | Excluded; resume on explicit invocation |
| Protected runtime reclaim of pre-existing/unrelated processes | Excluded; no such signals; conflicts report BLOCKED |
| Baseline catalog, ignore promotion and pre-existing-failure acceptance exceptions | Excluded from initial use; no ignores or ACCEPTABLE_WITH_IGNORED_FAILURES decisions |
| Flakiness/provenance automation, three-isolation-retry classification, earlier-snapshot comparisons and auxiliary diagnostic dispatch | Deferred; do not invoke or claim these capabilities |
| Portable evidence export/import and broad evidence-management UI | Deferred; local audit records, access controls, evidence index and bounded operational lookup retained |
| Automated pruning/rotation policy engine | Deferred; preserve necessary artifacts and permanent ID tombstones; bounded capture and storage-health admission still required |
| Distributed/remote workers or cross-clone coordination | Excluded; one verified local coordinator and approved local execution graph only |
| Per-choice method ledgers, coding diaries and repeated confirmation loops | Not required; retain material exception/amendment and actual acceptance evidence |

Owned-work termination under its original supervision grant is NOT runtime
reclaim and remains mandatory. A same-tier checked rerun after relevant edits is
NOT an auxiliary diagnostic capability; it remains possible under applicable
current authorization and actual limits. A passing retry cannot retrospectively
erase an earlier failure or establish pre-existing provenance.

Reclaim-dependent aliases/startup hooks must be identified. If any retained caller
depends on reclaim, safely remove that dependency through explicit approved scope
or block its integration/cutover. Missing providers cannot be called N/A while a
dependent caller remains. Do not modify Port Authority or other skills by implication.

These exclusions do not amend the installed Failure Gate v4 definition. Before
using this profile to govern execution, obtain and pin actual owner adoption of
the scoped contract and reconcile conflicting project instructions through their
authorized route. Do not claim an excluded full-v4 requirement has passed.
Previously active authority remains controlling until an authorized transition.

## Six ordered pairs

| Pair | Implementation | Independent verification and scoped repair | Declared stage |
|---|---|---|---|
| 01 | Reconcile existing discovery and propose/adopt exact scope through the real owner route | Verify current source/host mappings, exclusions, approval claims and fixed coverage | Discovery/source proposal |
| 02 | Stage IDs, durable coordinator, budgets, single-flight, supervision and recovery primitives | Inspect actual complete source and deny paths; carry runtime proof to 03/05 | Inert source |
| 03 | Establish safely admitted first bootstrap proof | Independently prove real local coordinator, bounds, containment and retained evidence | Bootstrap runtime only |
| 04 | Integrate tier registry, approvals, checked execution, input/result adapters and telemetry | Prove installed positive/negative/concurrency/compatibility behavior | Bootstrap integration; no ordinary cutover |
| 05 | Integrate validated completion, owner closure, restart/restore and exact recovery | Prove live writer race, mode separation, actual isolated restoration and non-reuse | Separately bounded bootstrap/recovery |
| 06 | Resolve retained-scope gaps, prove real callers and prepare the singular cutover | Fresh whole-profile assessment; final independent acceptance and authorized transition | Ordinary-route acceptance/cutover |

Dependencies are semantic until actual task refs exist:
`01-I -> 01-V -> 02-I -> 02-V -> 03-I -> 03-V -> 04-I -> 04-V -> 05-I -> 05-V -> 06-I -> 06-V`.
Acceptance, actual delivered successor inputs and new applicable scope/authority
must exist before advancing. A dependency label, Ready/Done, merge, source hash,
or owner administrative closure alone does not establish them.

Pair 06-I stops at pre-cutover preparation. Pair 06-V first obtains independent
current pre-cutover acceptance, then requires the genuine separately scoped
cutover decision before performing any ordinary-authority transition. Fresh
independent post-transition acceptance is required after its actual smoke proof;
the transition author cannot self-accept. If the independent route or permission
is absent, the pair remains pending at that boundary without ordinary activation.

The complete twelve task files in `tasks/` include their shared constraints.
Use those full payloads, not this table or a file link alone, if native tasks are
later separately authorized. At most one unfinished pair is current; leave later
pairs as repository backlog. No hook or automatic successor creation is authorized.

## Existing work and source reconciliation

Reuse independently substantiated facts and repairs from the current discovery
chain, including #158/#160/#161, only for their actual reviewed snapshots.
Those are observed historical platform refs, not new plan labels or local IDs.
The latest inspected independent assessment reports current-source acceptance
BLOCKED; do not inherit acceptance from its completed native lifecycle.

Pair 01 compares the controlling current `.agents` sources to that review,
records the affected submission-order/profile requirements and authentic authority,
and renews only dependent matrices/readbacks. Preserve unaffected supported
observations, original reports and the old detailed ledger. Do not restart every
inventory, refresh hashes to hide drift, reopen old tasks, zero an allocator, or
carry grants/budget consumption into this new operation as fresh permission.

Potential tracked project destination if installation is later authorized:
`docs/validation/failure-gate-core6/`, with twelve complete proposed task payloads
under the established `docs/validation/task-plans/` convention. These are proposed
destinations, not files installed in the project by this document.

## Execution and evidence rules

No actual command, tier, grant or finite budget value is selected in this
proposal. Pair 01 discovers real command graphs and sources; Pair 02 authors
inert checks; Pair 03 requires actual approval, effective finite values and safe
independent containment before any executable proof. UNKNOWN governance blocks
dependent execution, not honest drafting or separately authorized inert source.

For each actual run retain: local task or approved bootstrap operation identity;
complete plan/version; decision/source and policy versions; registered command
graph and tier definition; actual tested snapshot/environment; selected/effective
limits, consumed/remaining allowance and cleanup reserve; intent versus confirmed
launch; raw per-step status/signal and native reports; owned-tree termination,
capture/storage acknowledgements; uncertain outcomes and retained exclusion.
Use bounded collection and no secrets. Tests, fixtures and actual host readiness
are separate claims.

Both positive and negative acceptance cases have fixed expectations before
execution. A correctly denied request passes its denial criterion, not an
implementation requirement to make a missing capability work. Expected injected
failure preserves raw nonzero/timeout results. Actual containment failure,
missing required live proof, unknown accounting or absent independent acceptance
blocks the dependent claim.

Every verifier audits complete delivered inputs first, publishes material gaps
before repairing, repairs only its approved scope, invalidates affected evidence,
renews applicable proof and obtains fresh independent post-repair acceptance.
No arbitrary extra tests, tier escalation, budget renewal, unrelated bug fixes,
recursive verifier task creation, fabricated provider or self-approval.

An actual independently approved budget binds bootstrap runs, selected-tier
reruns, recovery and caller exercises separately as applicable. New wrapper/run
IDs, purpose changes, restart or restoration cannot reset consumed authority.
An exhausted budget or missing containment produces an exact scoped proposal,
not a guessed timeout, lock deletion or unmanaged experiment.

## Minimal deliverables

1. One installation manifest/index: source/profile versions, capability mapping,
   current pair/task refs, handoff bindings, authority locators and raw evidence locations.
2. One requirement-to-evidence matrix for C01-C20, with per-case expectations and
   snapshot/method bindings. Shared evidence can support multiple mapped criteria.
3. Six verifier acceptance reports, one per pair; installer handoff fields live in
   the manifest rather than duplicating another report for every pair.
4. The actual runtime implementation, storage schema, approved policy/registry,
   focused regression sources, and original raw records required for the retained scope.

No paragraph-by-paragraph replacement of the historical 1,961-unit ledger is
required. Preserve it as history; reconcile retained requirement coverage without
silently dropping applicable retained conjuncts or live acceptance cases.

## Pre-existing failures to ignore

None authorized. No baseline-ignore capability is included in initial Core.
Preserve known historical failures/repairs; classify unproven provenance as
unresolved. Missing required reports, failed retained checks, unsafe lifecycle or
stale proof cannot become a validated pass.

## Validation

This proposal is document authorship and source inspection only. No tests,
guards, imports, syntax/type/build checks, package commands, CLI/store operations,
runtime experiments, task writes or activation ran. Named regression paths are
prospective deliverables, not existing or executed tests. Each future task must
resolve its exact approved execution route and effective limits before dispatch.
Source acceptance at 01/02 does not satisfy runtime proof at 03/04/05/06.

## Regression Guard

**Covers:** Scope reduction accidentally removes permanent Task IDs, weakens retained approval/containment/completion controls, inherits old acceptance, or presents the scoped proposal as full v4 implementation.
**Test location:** scripts/test/failure-gate-core6-source.test.mjs — prospective inert source authored in Pair 01; executable proof only under actual later authorization.
**What it checks:** Retained C01-C20 mappings and exclusions; complete twelve payloads and six-stage ordering; no local IDs/grants invented; frozen acceptance criteria; old history preserved; no source/runtime/cutover conflation or full-v4 PASS claim.

## Relevant files

- Canonical `.agents/skills/failure-gate-v4/SKILL.md` and applicable `reference/` closure.
- Canonical `.agents/skills/paired-task-orchestration/SKILL.md` and `references/series-state-and-handoff.md`.
- Canonical `.agents/skills/skill-application-router/` handoff/delivery requirements.
- Canonical `.agents/skills/regression-guard/SKILL.md` and current `replit.md`.
- Existing `docs/validation/failure-gate-v4-task-series.md`, checkpoint and reimplementation manifest.
- Existing Piece 01 independent assessment and source/native readback evidence.
- This proposal, complete `tasks/` payloads and `source-readback.txt`.


---

# Complete proposed task payloads


---

[REGRESSION-GUARD] Classification: compatibility-contract. Guard: covered — scripts/test/failure-gate-core6-source.test.mjs.

# CORE6-01-I — Implement: Reconcile scope and current discovery

<!-- regression-guard: required -->

## Outcome and dependency

Owner: implementation context. Declared stage: Discovery and inert source proposal; no runtime. Requirement allocation: C04, C17, C18, C20; allocate every C01-C20 requirement. Semantic predecessor: No inherited accepted predecessor; reconcile the existing discovery chain without duplication. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Implementation scope

1. Read and pin current canonical .agents sources and applicable references; verify project/root/origin and current governing instructions. Reuse the existing discovery and independent observations for their supported snapshots, not their native lifecycle labels.

2. Compare the changed orchestration source against the blocked Piece 01 assessment. Identify affected requirements, actual controlling-version authority and necessary narrow renewal. Preserve unaffected supported facts and all historical ledgers/readbacks.

3. Publish one reduced-profile manifest and C01-C20 fixed outcome matrix. Map retained requirements to real source/installed boundaries and later proof gates. Explicitly mark the full-v4 capabilities removed/deferred, including the no-ignore failure policy.

4. Inventory real commands, tiers/coverage, independent callers, local store/IDs, writer coverage, approval sources and supervisor capabilities. Check reclaim-dependent aliases and deny unsupported remote dispatch. Inspect only through permitted read routes; do not initialize stores or infer current state from old documents.

5. Prepare concrete profile-adoption and first-proof proposals with actual owner routes, bounded scope and missing providers; record adoption only if genuinely obtained. Propose a versioned deterministic activation policy if no applicable approved policy exists. Profile adoption, bootstrap execution and ordinary cutover are distinct decisions.

6. Author the named inert source guard for complete six-pair/twelve-payload retention, excluded scope and no borrowed authority. No import, syntax check or test launch.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Current discovery | Project and sources are accurately bound; unrelated historical evidence retained | Actual readbacks and current/frozen differences; no invented namespace or current-store state |
| Fixed reduced contract | All C01-C20 outcomes remain covered; full-v4 exclusions expressly visible | Source-to-requirement matrix plus profile proposal; omission of Task ID non-reuse must reject |
| Authentic authority | Real adoption status and routes distinguished from proposals | Actual decision reference if present; missing adoption/approval remains pending, not approved |
| Dependency exclusions | No retained route silently requires deferred reclaim or remote dispatch | Actual alias/consumer graph and scoped remediation proposal; unavailable provider alone never N/A |
| Source-stage exit | Accurate complete proposal may accept as source/discovery; no runtime readiness | Inert guard source and independent current-source assessment; later authority blockers have named owner/action |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-01-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

The canonical-source/profile owner must resolve controlling-version authority and any conflicting full-v4/project scope before reduced-profile execution. The discovery custodian renews affected records; the integration custodian supplies actual approval/supervisor routes. Do not restart unrelated discovery or duplicate the old primary. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-01-I. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Source/document readback and inert source/test authorship only. No imports, syntax/type checks, tests/guards, builds, package commands, CLI/store initialization, runtime wiring or signals. Later live proof is explicitly assigned to Pairs 03-06; source-stage acceptance cannot stand in for it.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Current discovery; Fixed reduced contract; Authentic authority; Dependency exclusions; Source-stage exit; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-source.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Project and sources are accurately bound; unrelated historical evidence retained; All C01-C20 outcomes remain covered; full-v4 exclusions expressly visible; Real adoption status and routes distinguished from proposals; No retained route silently requires deferred reclaim or remote dispatch; Accurate complete proposal may accept as source/discovery; no runtime readiness. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-source.test.mjs, and actual delivered source/test paths resolved before execution.


---

[REGRESSION-GUARD] Classification: compatibility-contract. Guard: covered — scripts/test/failure-gate-core6-source.test.mjs.

# CORE6-01-V — Independently verify and repair: Reconcile scope and current discovery

<!-- regression-guard: required -->

## Outcome and dependency

Owner: fresh independent verifier context, not the primary author's success statement. Declared stage: Discovery and inert source proposal; no runtime. Requirement allocation: C04, C17, C18, C20; allocate every C01-C20 requirement. Semantic predecessor: CORE6-01-I. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Audit-first verification and scoped repair

1. Read the complete actual primary/verifier plans, adopted profile, current canonical closure and delivered inputs in this verifier's environment. Freeze the criteria below; independently resolve methods against installed wiring without deriving easier criteria from installer output.

2. Audit every assigned applicable outcome and publish the gap list BEFORE edits. Distinguish wrong/missing implementation, missing/stale proof and unavailable external authority. Record expected versus actual raw outcomes, evidence and verified/failed/blocked/justified-not-applicable status for every criterion.

3. Repair missing/wrong delivered implementation or scoped source/doc records within this approved pair's boundaries. Pair 06 may repair retained-scope omissions across the installation. No unrelated product fixes, hidden policy change, budget renewal, invented authority or extra tier execution.

4. Rebind repaired inputs and actual protected payload/decision through applicable amendment routes; invalidate affected evidence and renew required proof under genuine current limits. Correct expected denials/nonzero results are not bugs to repair to zero.

5. Obtain a fresh authorized independent post-repair readback/review with current evidence. A repair author's self-review is insufficient. Use an available independent host/fresh context route; do not recursively create tasks. If unavailable, mark acceptance blocked and propose the exact missing review route.

6. Publish one final pair report and update the single manifest/matrix with real evidence locators. Accept only the declared stage: source is not runtime, bootstrap is not ordinary cutover, and administrative closure is not validation. Do not prepare or run the successor in this task.

The primary scope audited by this verifier is included in full below; its fixed acceptance matrix is unchanged.

## Complete primary outcome scope

1. Read and pin current canonical .agents sources and applicable references; verify project/root/origin and current governing instructions. Reuse the existing discovery and independent observations for their supported snapshots, not their native lifecycle labels.

2. Compare the changed orchestration source against the blocked Piece 01 assessment. Identify affected requirements, actual controlling-version authority and necessary narrow renewal. Preserve unaffected supported facts and all historical ledgers/readbacks.

3. Publish one reduced-profile manifest and C01-C20 fixed outcome matrix. Map retained requirements to real source/installed boundaries and later proof gates. Explicitly mark the full-v4 capabilities removed/deferred, including the no-ignore failure policy.

4. Inventory real commands, tiers/coverage, independent callers, local store/IDs, writer coverage, approval sources and supervisor capabilities. Check reclaim-dependent aliases and deny unsupported remote dispatch. Inspect only through permitted read routes; do not initialize stores or infer current state from old documents.

5. Prepare concrete profile-adoption and first-proof proposals with actual owner routes, bounded scope and missing providers; record adoption only if genuinely obtained. Propose a versioned deterministic activation policy if no applicable approved policy exists. Profile adoption, bootstrap execution and ordinary cutover are distinct decisions.

6. Author the named inert source guard for complete six-pair/twelve-payload retention, excluded scope and no borrowed authority. No import, syntax check or test launch.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Current discovery | Project and sources are accurately bound; unrelated historical evidence retained | Actual readbacks and current/frozen differences; no invented namespace or current-store state |
| Fixed reduced contract | All C01-C20 outcomes remain covered; full-v4 exclusions expressly visible | Source-to-requirement matrix plus profile proposal; omission of Task ID non-reuse must reject |
| Authentic authority | Real adoption status and routes distinguished from proposals | Actual decision reference if present; missing adoption/approval remains pending, not approved |
| Dependency exclusions | No retained route silently requires deferred reclaim or remote dispatch | Actual alias/consumer graph and scoped remediation proposal; unavailable provider alone never N/A |
| Source-stage exit | Accurate complete proposal may accept as source/discovery; no runtime readiness | Inert guard source and independent current-source assessment; later authority blockers have named owner/action |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-01-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

The canonical-source/profile owner must resolve controlling-version authority and any conflicting full-v4/project scope before reduced-profile execution. The discovery custodian renews affected records; the integration custodian supplies actual approval/supervisor routes. Do not restart unrelated discovery or duplicate the old primary. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-01-V. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Source/document readback and inert source/test authorship only. No imports, syntax/type checks, tests/guards, builds, package commands, CLI/store initialization, runtime wiring or signals. Later live proof is explicitly assigned to Pairs 03-06; source-stage acceptance cannot stand in for it.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Current discovery; Fixed reduced contract; Authentic authority; Dependency exclusions; Source-stage exit; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-source.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Project and sources are accurately bound; unrelated historical evidence retained; All C01-C20 outcomes remain covered; full-v4 exclusions expressly visible; Real adoption status and routes distinguished from proposals; No retained route silently requires deferred reclaim or remote dispatch; Accurate complete proposal may accept as source/discovery; no runtime readiness. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-source.test.mjs, and actual delivered source/test paths resolved before execution.


---

[REGRESSION-GUARD] Classification: data-integrity, concurrency-lifecycle, performance-reliability. Guard: covered — scripts/test/failure-gate-core6-foundation.test.mjs.

# CORE6-02-I — Implement: Stage Task IDs and the safe foundation

<!-- regression-guard: required -->

## Outcome and dependency

Owner: implementation context. Declared stage: Inert source/schema/test authorship only. Requirement allocation: C01, C02, C03, C06, C07, C08, C10, C15, C16, C18. Semantic predecessor: CORE6-01-V, independently accepted with actual delivered inputs. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Implementation scope

1. Reuse the discovered appropriate local transactional store and host-language tooling. Author schema/migrations for a unique namespace, committed reservations, permanent tombstones, one task row/tier assignment, plan/decision bindings, CAS/idempotency and atomic mutation-with-audit.

2. Preserve existing committed identities/history. Stage reconciliation/import and fencing rules rather than deleting old state, renumbering or restarting the allocator. A platform task number is never local authorization.

3. Stage operation/run records, retained original accounting, atomic single-flight and cross-task resource primitives, queue revalidation and denial defaults. Track active/terminal/suspended states and prevent concurrent transition/launch races.

4. Author approved-budget source validation, safe finite representations, aggregate bounds, original parent deadline/consumption lineage and reserved cleanup/capture. Do not invent actual approved values or refund started failed/cancelled attempts.

5. Stage a real-provider adapter boundary for independent whole-entry supervision, private workload-gate registration before dispatch, exact owned children, bounded reads/capture and truthful typed termination/storage acknowledgements. Missing provider denies launch.

6. Stage restart/backup/restore and retained-error recovery rules: post-backup ID reconciliation, old-writer fencing, true/unfinalized/missing-field uncertainty retained, exact separately approved recovery acknowledgement. Author foundation and bootstrap fixture/guard sources; do not execute them or initialize the store.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| C01 permanent identities | Source enforces committed uniqueness, namespace and non-reuse across cancellation/deletion/import | Inspect actual constraints/transaction boundaries and authored race/restart/tombstone cases; actual allocation at 03, restore at 05 |
| C02/C03 authoritative bindings | One task assignment, versioned plan/decision and atomic audit; no competing editable allow lists | Actual source and negative stale/version/wrong-project/audit-failure cases |
| C06-C08 safe dispatch | Unproven/missing registration, invalid limits or uncertain child state denies dispatch/release | Complete adapter/gate/capture source and authored stall/late-zero/overflow/unknown-ack cases; runtime explicitly deferred to 03 |
| C10 coordination | Single-flight and resources retain exclusion until owned work is stopped or quarantined | Actual source for concurrent reservation, transition races and interrupted accounting |
| C15/C16 recovery | No state restore or recovery can reuse IDs, reset budgets or silently clear uncertainty | Inert restore/fencing/acknowledgement source and fixtures; actual isolated restore at 05 |
| Source-only exit | Complete inert implementation accepted only as source, without operation/store claims | Independently inspected actual delivered source/migrations; no imports/guards/tests/build/CLI/store launch |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-02-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

Storage and independent-supervisor integration owners supply real supported persistence/containment. Finish permitted source where possible. Before Pair 03 dispatch, missing authentic authority, effective limits or independent safe containment blocks the proposed proof; it cannot be replaced with a same-loop timer. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-02-I. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Source/document readback and inert source/test authorship only. No imports, syntax/type checks, tests/guards, builds, package commands, CLI/store initialization, runtime wiring or signals. Later live proof is explicitly assigned to Pairs 03-06; source-stage acceptance cannot stand in for it.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** C01 permanent identities; C02/C03 authoritative bindings; C06-C08 safe dispatch; C10 coordination; C15/C16 recovery; Source-only exit; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-foundation.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Source enforces committed uniqueness, namespace and non-reuse across cancellation/deletion/import; One task assignment, versioned plan/decision and atomic audit; no competing editable allow lists; Unproven/missing registration, invalid limits or uncertain child state denies dispatch/release; Single-flight and resources retain exclusion until owned work is stopped or quarantined; No state restore or recovery can reuse IDs, reset budgets or silently clear uncertainty; Complete inert implementation accepted only as source, without operation/store claims. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-foundation.test.mjs, and actual delivered source/test paths resolved before execution.


---

[REGRESSION-GUARD] Classification: data-integrity, concurrency-lifecycle, performance-reliability. Guard: covered — scripts/test/failure-gate-core6-foundation.test.mjs.

# CORE6-02-V — Independently verify and repair: Stage Task IDs and the safe foundation

<!-- regression-guard: required -->

## Outcome and dependency

Owner: fresh independent verifier context, not the primary author's success statement. Declared stage: Inert source/schema/test authorship only. Requirement allocation: C01, C02, C03, C06, C07, C08, C10, C15, C16, C18. Semantic predecessor: CORE6-02-I. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Audit-first verification and scoped repair

1. Read the complete actual primary/verifier plans, adopted profile, current canonical closure and delivered inputs in this verifier's environment. Freeze the criteria below; independently resolve methods against installed wiring without deriving easier criteria from installer output.

2. Audit every assigned applicable outcome and publish the gap list BEFORE edits. Distinguish wrong/missing implementation, missing/stale proof and unavailable external authority. Record expected versus actual raw outcomes, evidence and verified/failed/blocked/justified-not-applicable status for every criterion.

3. Repair missing/wrong delivered implementation or scoped source/doc records within this approved pair's boundaries. Pair 06 may repair retained-scope omissions across the installation. No unrelated product fixes, hidden policy change, budget renewal, invented authority or extra tier execution.

4. Rebind repaired inputs and actual protected payload/decision through applicable amendment routes; invalidate affected evidence and renew required proof under genuine current limits. Correct expected denials/nonzero results are not bugs to repair to zero.

5. Obtain a fresh authorized independent post-repair readback/review with current evidence. A repair author's self-review is insufficient. Use an available independent host/fresh context route; do not recursively create tasks. If unavailable, mark acceptance blocked and propose the exact missing review route.

6. Publish one final pair report and update the single manifest/matrix with real evidence locators. Accept only the declared stage: source is not runtime, bootstrap is not ordinary cutover, and administrative closure is not validation. Do not prepare or run the successor in this task.

The primary scope audited by this verifier is included in full below; its fixed acceptance matrix is unchanged.

## Complete primary outcome scope

1. Reuse the discovered appropriate local transactional store and host-language tooling. Author schema/migrations for a unique namespace, committed reservations, permanent tombstones, one task row/tier assignment, plan/decision bindings, CAS/idempotency and atomic mutation-with-audit.

2. Preserve existing committed identities/history. Stage reconciliation/import and fencing rules rather than deleting old state, renumbering or restarting the allocator. A platform task number is never local authorization.

3. Stage operation/run records, retained original accounting, atomic single-flight and cross-task resource primitives, queue revalidation and denial defaults. Track active/terminal/suspended states and prevent concurrent transition/launch races.

4. Author approved-budget source validation, safe finite representations, aggregate bounds, original parent deadline/consumption lineage and reserved cleanup/capture. Do not invent actual approved values or refund started failed/cancelled attempts.

5. Stage a real-provider adapter boundary for independent whole-entry supervision, private workload-gate registration before dispatch, exact owned children, bounded reads/capture and truthful typed termination/storage acknowledgements. Missing provider denies launch.

6. Stage restart/backup/restore and retained-error recovery rules: post-backup ID reconciliation, old-writer fencing, true/unfinalized/missing-field uncertainty retained, exact separately approved recovery acknowledgement. Author foundation and bootstrap fixture/guard sources; do not execute them or initialize the store.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| C01 permanent identities | Source enforces committed uniqueness, namespace and non-reuse across cancellation/deletion/import | Inspect actual constraints/transaction boundaries and authored race/restart/tombstone cases; actual allocation at 03, restore at 05 |
| C02/C03 authoritative bindings | One task assignment, versioned plan/decision and atomic audit; no competing editable allow lists | Actual source and negative stale/version/wrong-project/audit-failure cases |
| C06-C08 safe dispatch | Unproven/missing registration, invalid limits or uncertain child state denies dispatch/release | Complete adapter/gate/capture source and authored stall/late-zero/overflow/unknown-ack cases; runtime explicitly deferred to 03 |
| C10 coordination | Single-flight and resources retain exclusion until owned work is stopped or quarantined | Actual source for concurrent reservation, transition races and interrupted accounting |
| C15/C16 recovery | No state restore or recovery can reuse IDs, reset budgets or silently clear uncertainty | Inert restore/fencing/acknowledgement source and fixtures; actual isolated restore at 05 |
| Source-only exit | Complete inert implementation accepted only as source, without operation/store claims | Independently inspected actual delivered source/migrations; no imports/guards/tests/build/CLI/store launch |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-02-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

Storage and independent-supervisor integration owners supply real supported persistence/containment. Finish permitted source where possible. Before Pair 03 dispatch, missing authentic authority, effective limits or independent safe containment blocks the proposed proof; it cannot be replaced with a same-loop timer. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-02-V. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Source/document readback and inert source/test authorship only. No imports, syntax/type checks, tests/guards, builds, package commands, CLI/store initialization, runtime wiring or signals. Later live proof is explicitly assigned to Pairs 03-06; source-stage acceptance cannot stand in for it.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** C01 permanent identities; C02/C03 authoritative bindings; C06-C08 safe dispatch; C10 coordination; C15/C16 recovery; Source-only exit; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-foundation.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Source enforces committed uniqueness, namespace and non-reuse across cancellation/deletion/import; One task assignment, versioned plan/decision and atomic audit; no competing editable allow lists; Unproven/missing registration, invalid limits or uncertain child state denies dispatch/release; Single-flight and resources retain exclusion until owned work is stopped or quarantined; No state restore or recovery can reuse IDs, reset budgets or silently clear uncertainty; Complete inert implementation accepted only as source, without operation/store claims. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-foundation.test.mjs, and actual delivered source/test paths resolved before execution.


---

[REGRESSION-GUARD] Classification: data-integrity, concurrency-lifecycle, performance-reliability. Guard: covered — scripts/test/failure-gate-core6-bootstrap.test.mjs.

# CORE6-03-I — Implement: Prove the real bootstrap foundation

<!-- regression-guard: required -->

## Outcome and dependency

Owner: implementation context. Declared stage: Separately approved bounded bootstrap runtime; ordinary route disabled. Requirement allocation: C01, C06, C07, C08, C09 capture, C10 foundation, C11 bootstrap evidence, C16, C18. Semantic predecessor: CORE6-02-V, independently accepted with actual delivered inputs. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Implementation scope

1. Verify accepted delivered Pair 02 inputs and the actual adopted profile/current governance. Pin a fresh exact bootstrap operation/decision, approved source closure, command graph, environment and independently approved finite phase/parent/attempt values. Prior grants and remembered timeouts are not usable authority.

2. Before any stall/hang exercise, admit the first proof through an independently safe existing carrier. Establish actual registration/containment with controlled isolated workloads; do not require the future proof already passed to propose it, and do not run an uncontained experiment.

3. Under scoped permission, initialize/exercise the real local coordinator and prove concurrent committed uniqueness, audit rollback, CAS/idempotency, non-reuse and retained original accounting. Keep these isolated test identities distinct from production and platform task refs.

4. Prove the installed external supervisor against approved async/synchronous/hook/setup/teardown stalls, owner loss, watchdog loss, owned children, deadline/capture/storage failure and unknown acknowledgements. Preserve exclusion until actual stopped/quarantined evidence; never kill unrelated listeners.

5. Retain original intent/start/finish reports, raw status/signal, effective limits/consumption, clock lineage, registration/termination/capture evidence and expected-injected versus failed-acceptance distinctions.

6. Obtain two consecutive real authorized caller runs through the installed bootstrap route before enabled-bootstrap readiness claims, within genuinely approved repetitions and remaining limits. Register only the accepted bootstrap carrier; never ordinary activation/cutover.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Real admission | No workload before authentic scope, safe outer containment and registration | Actual operation/decision and provider registration records; flag/status/missing-provider paths must launch nothing |
| Real IDs | Concurrent committed allocation unique; cancelled/deleted identities not reused; audit failure rolls back | Actual isolated host store/transaction records, restart observations and raw selected fixture reports |
| Finite containment | Approved hangs terminate or remain explicitly quarantined within bounds; late zero never passes | Original independent supervisor and exact owned-tree evidence, including owner/watchdog loss and child survival negative cases |
| Capture/accounting integrity | Bounded output and typed acknowledgements; no new run ID or restart resets consumption | Raw overflow/uncertainty evidence plus original accounting; malformed acknowledgements never healthy release |
| Bootstrap readiness | Two consecutive real authorized installed-route caller runs, not just mocked fixtures | Actual separately identified caller/run evidence with current snapshot and approved repetitions; ordinary disabled |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-03-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

The bootstrap authority owner supplies an authentic fresh bounded decision; independent supervisor owner supplies verified safe containment. Insufficient remaining limits, unsafe containment or unknown owned-work state stops conflicting work, retains evidence/exclusion and produces an exact remediation/recovery proposal. No automatic rerun or counter reset. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-03-I. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Actual executable validation is pending this task's separate approval and verified prerequisites. Resolve the exact registered tier or bounded bootstrap/recovery capability, actual command/selectors/transitive graph, authentic bound decision, independently approved effective finite values and remaining allowance before dispatch. Use the accepted safe carrier; no invented default timeout or generic shell authority. Missing authority, containment, logging, actual proof or independent acceptance blocks the affected readiness claim.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Real admission; Real IDs; Finite containment; Capture/accounting integrity; Bootstrap readiness; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-bootstrap.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** No workload before authentic scope, safe outer containment and registration; Concurrent committed allocation unique; cancelled/deleted identities not reused; audit failure rolls back; Approved hangs terminate or remain explicitly quarantined within bounds; late zero never passes; Bounded output and typed acknowledgements; no new run ID or restart resets consumption; Two consecutive real authorized installed-route caller runs, not just mocked fixtures. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-bootstrap.test.mjs, and actual delivered source/test paths resolved before execution.


---

[REGRESSION-GUARD] Classification: data-integrity, concurrency-lifecycle, performance-reliability. Guard: covered — scripts/test/failure-gate-core6-bootstrap.test.mjs.

# CORE6-03-V — Independently verify and repair: Prove the real bootstrap foundation

<!-- regression-guard: required -->

## Outcome and dependency

Owner: fresh independent verifier context, not the primary author's success statement. Declared stage: Separately approved bounded bootstrap runtime; ordinary route disabled. Requirement allocation: C01, C06, C07, C08, C09 capture, C10 foundation, C11 bootstrap evidence, C16, C18. Semantic predecessor: CORE6-03-I. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Audit-first verification and scoped repair

1. Read the complete actual primary/verifier plans, adopted profile, current canonical closure and delivered inputs in this verifier's environment. Freeze the criteria below; independently resolve methods against installed wiring without deriving easier criteria from installer output.

2. Audit every assigned applicable outcome and publish the gap list BEFORE edits. Distinguish wrong/missing implementation, missing/stale proof and unavailable external authority. Record expected versus actual raw outcomes, evidence and verified/failed/blocked/justified-not-applicable status for every criterion.

3. Repair missing/wrong delivered implementation or scoped source/doc records within this approved pair's boundaries. Pair 06 may repair retained-scope omissions across the installation. No unrelated product fixes, hidden policy change, budget renewal, invented authority or extra tier execution.

4. Rebind repaired inputs and actual protected payload/decision through applicable amendment routes; invalidate affected evidence and renew required proof under genuine current limits. Correct expected denials/nonzero results are not bugs to repair to zero.

5. Obtain a fresh authorized independent post-repair readback/review with current evidence. A repair author's self-review is insufficient. Use an available independent host/fresh context route; do not recursively create tasks. If unavailable, mark acceptance blocked and propose the exact missing review route.

6. Publish one final pair report and update the single manifest/matrix with real evidence locators. Accept only the declared stage: source is not runtime, bootstrap is not ordinary cutover, and administrative closure is not validation. Do not prepare or run the successor in this task.

The primary scope audited by this verifier is included in full below; its fixed acceptance matrix is unchanged.

## Complete primary outcome scope

1. Verify accepted delivered Pair 02 inputs and the actual adopted profile/current governance. Pin a fresh exact bootstrap operation/decision, approved source closure, command graph, environment and independently approved finite phase/parent/attempt values. Prior grants and remembered timeouts are not usable authority.

2. Before any stall/hang exercise, admit the first proof through an independently safe existing carrier. Establish actual registration/containment with controlled isolated workloads; do not require the future proof already passed to propose it, and do not run an uncontained experiment.

3. Under scoped permission, initialize/exercise the real local coordinator and prove concurrent committed uniqueness, audit rollback, CAS/idempotency, non-reuse and retained original accounting. Keep these isolated test identities distinct from production and platform task refs.

4. Prove the installed external supervisor against approved async/synchronous/hook/setup/teardown stalls, owner loss, watchdog loss, owned children, deadline/capture/storage failure and unknown acknowledgements. Preserve exclusion until actual stopped/quarantined evidence; never kill unrelated listeners.

5. Retain original intent/start/finish reports, raw status/signal, effective limits/consumption, clock lineage, registration/termination/capture evidence and expected-injected versus failed-acceptance distinctions.

6. Obtain two consecutive real authorized caller runs through the installed bootstrap route before enabled-bootstrap readiness claims, within genuinely approved repetitions and remaining limits. Register only the accepted bootstrap carrier; never ordinary activation/cutover.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Real admission | No workload before authentic scope, safe outer containment and registration | Actual operation/decision and provider registration records; flag/status/missing-provider paths must launch nothing |
| Real IDs | Concurrent committed allocation unique; cancelled/deleted identities not reused; audit failure rolls back | Actual isolated host store/transaction records, restart observations and raw selected fixture reports |
| Finite containment | Approved hangs terminate or remain explicitly quarantined within bounds; late zero never passes | Original independent supervisor and exact owned-tree evidence, including owner/watchdog loss and child survival negative cases |
| Capture/accounting integrity | Bounded output and typed acknowledgements; no new run ID or restart resets consumption | Raw overflow/uncertainty evidence plus original accounting; malformed acknowledgements never healthy release |
| Bootstrap readiness | Two consecutive real authorized installed-route caller runs, not just mocked fixtures | Actual separately identified caller/run evidence with current snapshot and approved repetitions; ordinary disabled |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-03-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

The bootstrap authority owner supplies an authentic fresh bounded decision; independent supervisor owner supplies verified safe containment. Insufficient remaining limits, unsafe containment or unknown owned-work state stops conflicting work, retains evidence/exclusion and produces an exact remediation/recovery proposal. No automatic rerun or counter reset. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-03-V. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Actual executable validation is pending this task's separate approval and verified prerequisites. Resolve the exact registered tier or bounded bootstrap/recovery capability, actual command/selectors/transitive graph, authentic bound decision, independently approved effective finite values and remaining allowance before dispatch. Use the accepted safe carrier; no invented default timeout or generic shell authority. Missing authority, containment, logging, actual proof or independent acceptance blocks the affected readiness claim.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Real admission; Real IDs; Finite containment; Capture/accounting integrity; Bootstrap readiness; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-bootstrap.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** No workload before authentic scope, safe outer containment and registration; Concurrent committed allocation unique; cancelled/deleted identities not reused; audit failure rolls back; Approved hangs terminate or remain explicitly quarantined within bounds; late zero never passes; Bounded output and typed acknowledgements; no new run ID or restart resets consumption; Two consecutive real authorized installed-route caller runs, not just mocked fixtures. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-bootstrap.test.mjs, and actual delivered source/test paths resolved before execution.


---

[REGRESSION-GUARD] Classification: security-privacy, data-integrity, concurrency-lifecycle, compatibility-contract. Guard: covered — scripts/test/failure-gate-core6-execution.test.mjs.

# CORE6-04-I — Implement: Integrate authorization and checked execution

<!-- regression-guard: required -->

## Outcome and dependency

Owner: implementation context. Declared stage: Accepted bootstrap integration; ordinary route not cut over. Requirement allocation: C02, C03, C04, C05, C06, C07, C08, C09, C10, C11, C12, C17, C18. Semantic predecessor: CORE6-03-V, independently accepted with actual delivered inputs. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Implementation scope

1. Register the discovered real checks with preserved coverage, argv, hooks/branches, configuration inputs, reports and locks. Author bounded pre-activation guards on draft records; no invented tier defaults or unrestricted argument passthrough.

2. Implement actual supported approval/decision ingestion and exact local task/plan/tier/definition/parameter/policy bindings. Reuse a genuinely owner-approved deterministic policy only for matching scope; each activation/amendment records a fresh atomic bound decision. A Replit approval event needs verified contents, not an invented actor roster.

3. Integrate checked activation and selected-tier execution through the coordinator. Deny malformed/stale/wrong-project/wrong-plan/terminal/suspended/other-tier/undeclared transitive requests before launch. Do not turn explicit checked rejection into an independent fallback.

4. Integrate bounded configuration/preflight and input reads, actual tested-content/environment manifests, native report parsing, secret redaction and raw status/signal. Mutation during run, missing required input/report, skipped/zero-discovery/cancelled/late-zero outcomes remain incomplete/failing, not PASS.

5. Exercise atomic single-flight, duplicates/bounded queue, queued revocation, resource conflicts, authorized parallel children and child-aware release. Capture durable decisions/intents/confirmed starts/finishes/denials/uncertainty outside .local and expose one bounded read-only operational lookup.

6. Preserve genuine independent invocations, coverage and existing authority without adding task metadata. Their reports cannot satisfy selected-tier evidence. Initial failure policy has no ignores, diagnostic dispatch or provenance acceptance; retain failures/owned repairs and allow only applicable checked same-tier reruns.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Exact authorization | Only genuinely approved exact bindings activate; changes require fresh applicable decision | Actual trusted decision source and atomic records; forged flags, status/command/merge pseudo-approvals, wrong ID/tier/version deny |
| Selected-tier execution | One registered covered tier executes; unsupported/expanded graphs launch nothing | Real checked bootstrap-subject run plus isolated instrumented denial cases; never unauthorized live tier sweeps |
| Input/result integrity | Actual snapshot/native report and raw exits/signals; no missing, stale, skipped or late-zero PASS | Installed adapter proof with safe malformed/config-drift/report/capture/snapshot mutation cases |
| Concurrency/lifetime | At most one cooperative top-level launch per task/operation; queued work revalidated; owned children remain accounted | Actual run/lease/intent records and bounded same-task/cross-task/cancellation races |
| Minimal telemetry | Durable trail corroborates confirmed launches and preserves unknowns/crash gaps | Actual indexed events and bounded read-only lookup; logging failure blocks applicable managed launch/acceptance |
| Compatibility/failures | Existing independent commands retain authority/coverage; raw failures/repairs never become ignores | Configured-versus-installed comparison and authorized local caller proof; independent/direct/lucky-retry reports cannot satisfy checked completion |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-04-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

Approval integration and registry owners resolve real decision/coverage routes. Monitor/input adapters and coordination owners implement missing installed boundaries. Preserve old ordinary authority; missing actual approval, logs, required reports or child safety blocks dependent integration claims rather than inventing a fallback. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-04-I. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Actual executable validation is pending this task's separate approval and verified prerequisites. Resolve the exact registered tier or bounded bootstrap/recovery capability, actual command/selectors/transitive graph, authentic bound decision, independently approved effective finite values and remaining allowance before dispatch. Use the accepted safe carrier; no invented default timeout or generic shell authority. Missing authority, containment, logging, actual proof or independent acceptance blocks the affected readiness claim.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Exact authorization; Selected-tier execution; Input/result integrity; Concurrency/lifetime; Minimal telemetry; Compatibility/failures; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-execution.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Only genuinely approved exact bindings activate; changes require fresh applicable decision; One registered covered tier executes; unsupported/expanded graphs launch nothing; Actual snapshot/native report and raw exits/signals; no missing, stale, skipped or late-zero PASS; At most one cooperative top-level launch per task/operation; queued work revalidated; owned children remain accounted; Durable trail corroborates confirmed launches and preserves unknowns/crash gaps; Existing independent commands retain authority/coverage; raw failures/repairs never become ignores. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-execution.test.mjs, and actual delivered source/test paths resolved before execution.


---

[REGRESSION-GUARD] Classification: security-privacy, data-integrity, concurrency-lifecycle, compatibility-contract. Guard: covered — scripts/test/failure-gate-core6-execution.test.mjs.

# CORE6-04-V — Independently verify and repair: Integrate authorization and checked execution

<!-- regression-guard: required -->

## Outcome and dependency

Owner: fresh independent verifier context, not the primary author's success statement. Declared stage: Accepted bootstrap integration; ordinary route not cut over. Requirement allocation: C02, C03, C04, C05, C06, C07, C08, C09, C10, C11, C12, C17, C18. Semantic predecessor: CORE6-04-I. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Audit-first verification and scoped repair

1. Read the complete actual primary/verifier plans, adopted profile, current canonical closure and delivered inputs in this verifier's environment. Freeze the criteria below; independently resolve methods against installed wiring without deriving easier criteria from installer output.

2. Audit every assigned applicable outcome and publish the gap list BEFORE edits. Distinguish wrong/missing implementation, missing/stale proof and unavailable external authority. Record expected versus actual raw outcomes, evidence and verified/failed/blocked/justified-not-applicable status for every criterion.

3. Repair missing/wrong delivered implementation or scoped source/doc records within this approved pair's boundaries. Pair 06 may repair retained-scope omissions across the installation. No unrelated product fixes, hidden policy change, budget renewal, invented authority or extra tier execution.

4. Rebind repaired inputs and actual protected payload/decision through applicable amendment routes; invalidate affected evidence and renew required proof under genuine current limits. Correct expected denials/nonzero results are not bugs to repair to zero.

5. Obtain a fresh authorized independent post-repair readback/review with current evidence. A repair author's self-review is insufficient. Use an available independent host/fresh context route; do not recursively create tasks. If unavailable, mark acceptance blocked and propose the exact missing review route.

6. Publish one final pair report and update the single manifest/matrix with real evidence locators. Accept only the declared stage: source is not runtime, bootstrap is not ordinary cutover, and administrative closure is not validation. Do not prepare or run the successor in this task.

The primary scope audited by this verifier is included in full below; its fixed acceptance matrix is unchanged.

## Complete primary outcome scope

1. Register the discovered real checks with preserved coverage, argv, hooks/branches, configuration inputs, reports and locks. Author bounded pre-activation guards on draft records; no invented tier defaults or unrestricted argument passthrough.

2. Implement actual supported approval/decision ingestion and exact local task/plan/tier/definition/parameter/policy bindings. Reuse a genuinely owner-approved deterministic policy only for matching scope; each activation/amendment records a fresh atomic bound decision. A Replit approval event needs verified contents, not an invented actor roster.

3. Integrate checked activation and selected-tier execution through the coordinator. Deny malformed/stale/wrong-project/wrong-plan/terminal/suspended/other-tier/undeclared transitive requests before launch. Do not turn explicit checked rejection into an independent fallback.

4. Integrate bounded configuration/preflight and input reads, actual tested-content/environment manifests, native report parsing, secret redaction and raw status/signal. Mutation during run, missing required input/report, skipped/zero-discovery/cancelled/late-zero outcomes remain incomplete/failing, not PASS.

5. Exercise atomic single-flight, duplicates/bounded queue, queued revocation, resource conflicts, authorized parallel children and child-aware release. Capture durable decisions/intents/confirmed starts/finishes/denials/uncertainty outside .local and expose one bounded read-only operational lookup.

6. Preserve genuine independent invocations, coverage and existing authority without adding task metadata. Their reports cannot satisfy selected-tier evidence. Initial failure policy has no ignores, diagnostic dispatch or provenance acceptance; retain failures/owned repairs and allow only applicable checked same-tier reruns.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Exact authorization | Only genuinely approved exact bindings activate; changes require fresh applicable decision | Actual trusted decision source and atomic records; forged flags, status/command/merge pseudo-approvals, wrong ID/tier/version deny |
| Selected-tier execution | One registered covered tier executes; unsupported/expanded graphs launch nothing | Real checked bootstrap-subject run plus isolated instrumented denial cases; never unauthorized live tier sweeps |
| Input/result integrity | Actual snapshot/native report and raw exits/signals; no missing, stale, skipped or late-zero PASS | Installed adapter proof with safe malformed/config-drift/report/capture/snapshot mutation cases |
| Concurrency/lifetime | At most one cooperative top-level launch per task/operation; queued work revalidated; owned children remain accounted | Actual run/lease/intent records and bounded same-task/cross-task/cancellation races |
| Minimal telemetry | Durable trail corroborates confirmed launches and preserves unknowns/crash gaps | Actual indexed events and bounded read-only lookup; logging failure blocks applicable managed launch/acceptance |
| Compatibility/failures | Existing independent commands retain authority/coverage; raw failures/repairs never become ignores | Configured-versus-installed comparison and authorized local caller proof; independent/direct/lucky-retry reports cannot satisfy checked completion |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-04-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

Approval integration and registry owners resolve real decision/coverage routes. Monitor/input adapters and coordination owners implement missing installed boundaries. Preserve old ordinary authority; missing actual approval, logs, required reports or child safety blocks dependent integration claims rather than inventing a fallback. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-04-V. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Actual executable validation is pending this task's separate approval and verified prerequisites. Resolve the exact registered tier or bounded bootstrap/recovery capability, actual command/selectors/transitive graph, authentic bound decision, independently approved effective finite values and remaining allowance before dispatch. Use the accepted safe carrier; no invented default timeout or generic shell authority. Missing authority, containment, logging, actual proof or independent acceptance blocks the affected readiness claim.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Exact authorization; Selected-tier execution; Input/result integrity; Concurrency/lifetime; Minimal telemetry; Compatibility/failures; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-execution.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Only genuinely approved exact bindings activate; changes require fresh applicable decision; One registered covered tier executes; unsupported/expanded graphs launch nothing; Actual snapshot/native report and raw exits/signals; no missing, stale, skipped or late-zero PASS; At most one cooperative top-level launch per task/operation; queued work revalidated; owned children remain accounted; Durable trail corroborates confirmed launches and preserves unknowns/crash gaps; Existing independent commands retain authority/coverage; raw failures/repairs never become ignores. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-execution.test.mjs, and actual delivered source/test paths resolved before execution.


---

[REGRESSION-GUARD] Classification: data-integrity, concurrency-lifecycle, error-handling, compatibility-contract. Guard: covered — scripts/test/failure-gate-core6-completion-recovery.test.mjs.

# CORE6-05-I — Implement: Prove completion, closure and recovery

<!-- regression-guard: required -->

## Outcome and dependency

Owner: implementation context. Declared stage: Bounded bootstrap completion tests and separately approved isolated recovery/restore. Requirement allocation: C01, C06, C08, C11 mode visibility, C12, C13, C14, C15, C16, C17 writer coverage, C18. Semantic predecessor: CORE6-04-V, independently accepted with actual delivered inputs. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Implementation scope

1. Discover all effective accepted-state writers and implement verified coordination or immutable accepted-snapshot isolation. The local completion checker must use complete current selected-tier results, exact task/plan/decision/run bindings, current owned-repair state and actual tested inputs.

2. Perform an authorized real installed-path final-writer race; demonstrate a competing write cannot turn stale/incomplete/wrong-task/direct/independent evidence into validated completion. A flock primitive or mocked checker alone is insufficient; uncoordinated writers block stronger claims.

3. Implement explicit task-scoped owner_direction closure separate from validated completion. Retain actual failures/not-run/repairs, revoke local permissions atomically with audit and safe owned-run handling, make readers distinguish modes, and honor authentic owner direction without a second validation approval. Use isolated approved subjects, never close a real task unasked.

4. Under separate exact bounded drill permission, exercise the actual host backup format in an isolated restore. Preserve namespace/tombstones and post-backup committed IDs, fence old writers and prevent stale approvals/budget resurrection. No production restore, allocator reset or live lease clearing.

5. Implement/prove exact retained-error recovery with original incident/task/operation/incarnation/accounting bindings, contender/unknown-commit reconciliation and durable authentic acknowledgement. Timeout or local quiescence alone never releases true/unfinalized/missing-field or authoritative uncertainty.

6. Keep necessary evidence and permanent identities accessible, secret-safe and visibly indexed. Minimal bounded state/record health needed for admission/readers remains; automated pruning/export/broad evidence-management UI remains excluded.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Current validated completion | Only complete applicable current selected-tier evidence plus fulfilled owned repairs permits local validated mode | Actual installed checker and terminal transaction; stale/wrong-task/direct/skipped/missing/failed evidence denies |
| Real final-writer proof | Accepted-state race cannot associate validation with different contents | Authorized installed-path race and effective writer/isolation inventory; incomplete coverage explicitly blocks acceptance |
| Administrative closure | Authentic exact direction closes safely without converting failures to PASS | Isolated decision/mode/audit/readers/repeat/race cases; all tiers revoked and uncertain children never orphaned |
| Actual restoration | Real isolated host-format restore reconciles later committed IDs and fences old writers | Actual backup/checkpoint identity, restore report, tombstone/post-backup comparisons and renewed permission bindings; mocks not readiness |
| Retained-error recovery | Only authentic scoped reconciliation and acknowledged outcome releases the affected exclusion | Exact incident/decision/contender/commit/ack records; stale/unknown/malformed/legacy paths remain excluded |
| Evidence/consumption | History, owned repairs and consumed budgets survive restart/restore/closure | Actual durable records and mode-aware lookup; no pruning, counter reset, terminal reopen or catalog ignore |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-05-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

The writer/isolation owner resolves effective accepted-state coverage. Recovery/storage authority supplies separately approved safe drill and exact incident handling. Missing proof blocks completion/recovery readiness; do not clear live exclusions or restore production to manufacture a pass. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-05-I. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Actual executable validation is pending this task's separate approval and verified prerequisites. Resolve the exact registered tier or bounded bootstrap/recovery capability, actual command/selectors/transitive graph, authentic bound decision, independently approved effective finite values and remaining allowance before dispatch. Use the accepted safe carrier; no invented default timeout or generic shell authority. Missing authority, containment, logging, actual proof or independent acceptance blocks the affected readiness claim.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Current validated completion; Real final-writer proof; Administrative closure; Actual restoration; Retained-error recovery; Evidence/consumption; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-completion-recovery.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Only complete applicable current selected-tier evidence plus fulfilled owned repairs permits local validated mode; Accepted-state race cannot associate validation with different contents; Authentic exact direction closes safely without converting failures to PASS; Real isolated host-format restore reconciles later committed IDs and fences old writers; Only authentic scoped reconciliation and acknowledged outcome releases the affected exclusion; History, owned repairs and consumed budgets survive restart/restore/closure. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-completion-recovery.test.mjs, and actual delivered source/test paths resolved before execution.


---

[REGRESSION-GUARD] Classification: data-integrity, concurrency-lifecycle, error-handling, compatibility-contract. Guard: covered — scripts/test/failure-gate-core6-completion-recovery.test.mjs.

# CORE6-05-V — Independently verify and repair: Prove completion, closure and recovery

<!-- regression-guard: required -->

## Outcome and dependency

Owner: fresh independent verifier context, not the primary author's success statement. Declared stage: Bounded bootstrap completion tests and separately approved isolated recovery/restore. Requirement allocation: C01, C06, C08, C11 mode visibility, C12, C13, C14, C15, C16, C17 writer coverage, C18. Semantic predecessor: CORE6-05-I. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Audit-first verification and scoped repair

1. Read the complete actual primary/verifier plans, adopted profile, current canonical closure and delivered inputs in this verifier's environment. Freeze the criteria below; independently resolve methods against installed wiring without deriving easier criteria from installer output.

2. Audit every assigned applicable outcome and publish the gap list BEFORE edits. Distinguish wrong/missing implementation, missing/stale proof and unavailable external authority. Record expected versus actual raw outcomes, evidence and verified/failed/blocked/justified-not-applicable status for every criterion.

3. Repair missing/wrong delivered implementation or scoped source/doc records within this approved pair's boundaries. Pair 06 may repair retained-scope omissions across the installation. No unrelated product fixes, hidden policy change, budget renewal, invented authority or extra tier execution.

4. Rebind repaired inputs and actual protected payload/decision through applicable amendment routes; invalidate affected evidence and renew required proof under genuine current limits. Correct expected denials/nonzero results are not bugs to repair to zero.

5. Obtain a fresh authorized independent post-repair readback/review with current evidence. A repair author's self-review is insufficient. Use an available independent host/fresh context route; do not recursively create tasks. If unavailable, mark acceptance blocked and propose the exact missing review route.

6. Publish one final pair report and update the single manifest/matrix with real evidence locators. Accept only the declared stage: source is not runtime, bootstrap is not ordinary cutover, and administrative closure is not validation. Do not prepare or run the successor in this task.

The primary scope audited by this verifier is included in full below; its fixed acceptance matrix is unchanged.

## Complete primary outcome scope

1. Discover all effective accepted-state writers and implement verified coordination or immutable accepted-snapshot isolation. The local completion checker must use complete current selected-tier results, exact task/plan/decision/run bindings, current owned-repair state and actual tested inputs.

2. Perform an authorized real installed-path final-writer race; demonstrate a competing write cannot turn stale/incomplete/wrong-task/direct/independent evidence into validated completion. A flock primitive or mocked checker alone is insufficient; uncoordinated writers block stronger claims.

3. Implement explicit task-scoped owner_direction closure separate from validated completion. Retain actual failures/not-run/repairs, revoke local permissions atomically with audit and safe owned-run handling, make readers distinguish modes, and honor authentic owner direction without a second validation approval. Use isolated approved subjects, never close a real task unasked.

4. Under separate exact bounded drill permission, exercise the actual host backup format in an isolated restore. Preserve namespace/tombstones and post-backup committed IDs, fence old writers and prevent stale approvals/budget resurrection. No production restore, allocator reset or live lease clearing.

5. Implement/prove exact retained-error recovery with original incident/task/operation/incarnation/accounting bindings, contender/unknown-commit reconciliation and durable authentic acknowledgement. Timeout or local quiescence alone never releases true/unfinalized/missing-field or authoritative uncertainty.

6. Keep necessary evidence and permanent identities accessible, secret-safe and visibly indexed. Minimal bounded state/record health needed for admission/readers remains; automated pruning/export/broad evidence-management UI remains excluded.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Current validated completion | Only complete applicable current selected-tier evidence plus fulfilled owned repairs permits local validated mode | Actual installed checker and terminal transaction; stale/wrong-task/direct/skipped/missing/failed evidence denies |
| Real final-writer proof | Accepted-state race cannot associate validation with different contents | Authorized installed-path race and effective writer/isolation inventory; incomplete coverage explicitly blocks acceptance |
| Administrative closure | Authentic exact direction closes safely without converting failures to PASS | Isolated decision/mode/audit/readers/repeat/race cases; all tiers revoked and uncertain children never orphaned |
| Actual restoration | Real isolated host-format restore reconciles later committed IDs and fences old writers | Actual backup/checkpoint identity, restore report, tombstone/post-backup comparisons and renewed permission bindings; mocks not readiness |
| Retained-error recovery | Only authentic scoped reconciliation and acknowledged outcome releases the affected exclusion | Exact incident/decision/contender/commit/ack records; stale/unknown/malformed/legacy paths remain excluded |
| Evidence/consumption | History, owned repairs and consumed budgets survive restart/restore/closure | Actual durable records and mode-aware lookup; no pruning, counter reset, terminal reopen or catalog ignore |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-05-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

The writer/isolation owner resolves effective accepted-state coverage. Recovery/storage authority supplies separately approved safe drill and exact incident handling. Missing proof blocks completion/recovery readiness; do not clear live exclusions or restore production to manufacture a pass. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-05-V. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Actual executable validation is pending this task's separate approval and verified prerequisites. Resolve the exact registered tier or bounded bootstrap/recovery capability, actual command/selectors/transitive graph, authentic bound decision, independently approved effective finite values and remaining allowance before dispatch. Use the accepted safe carrier; no invented default timeout or generic shell authority. Missing authority, containment, logging, actual proof or independent acceptance blocks the affected readiness claim.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Current validated completion; Real final-writer proof; Administrative closure; Actual restoration; Retained-error recovery; Evidence/consumption; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-completion-recovery.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Only complete applicable current selected-tier evidence plus fulfilled owned repairs permits local validated mode; Accepted-state race cannot associate validation with different contents; Authentic exact direction closes safely without converting failures to PASS; Real isolated host-format restore reconciles later committed IDs and fences old writers; Only authentic scoped reconciliation and acknowledged outcome releases the affected exclusion; History, owned repairs and consumed budgets survive restart/restore/closure. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-completion-recovery.test.mjs, and actual delivered source/test paths resolved before execution.


---

[REGRESSION-GUARD] Classification: security-privacy, data-integrity, concurrency-lifecycle, compatibility-contract. Guard: covered — scripts/test/failure-gate-core6-cutover.test.mjs.

# CORE6-06-I — Implement: Accept the Core installation and authorize cutover

<!-- regression-guard: required -->

## Outcome and dependency

Owner: implementation context. Declared stage: Pre-cutover preparation only; actual C19 transition and final acceptance deferred to CORE6-06-V. Requirement allocation: Every C01-C20 retained requirement. Semantic predecessor: CORE6-05-V, independently accepted with actual delivered inputs. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Implementation scope

1. Reconcile the complete adopted Core version against current canonical/project instructions, source closure, actual implementation/wiring, accepted earlier matrices and current environment. Invalidate only affected evidence and renew it through real applicable authority; full-v4 exclusions remain visible.

2. Resolve remaining retained-scope omissions under approved overall installation scope. Preserve coverage, raw failures, original accounting and material amendment routes. Repaired inputs require renewed checks and fresh independent acceptance; do not fix unrelated app bugs.

3. Exercise every required retained local checked and genuine independent caller under its actual authority and verified finite containment. Use real local IDs/approved plans/current selected-tier reports for checked callers. Each enabled control/caller requires two consecutive real authorized runs within approved repetitions.

4. Verify current actual final-writer race, isolated restore/non-reuse, safe active/uncertain-run handling, durable telemetry and no excluded reclaim/remote dependency. Controlled denial fixtures do not replace these live proofs or authorize an all-tier sweep.

5. Prepare the exact singular ordinary-route transition under prior governance: version/scope, intended old/new authority, eligibility, quiescence, conflict fencing, migration, admission checks, evidence and fail-closed interruption/recovery. Do not silently turn bootstrap success or policy adoption into cutover consent.

6. Deliver the complete pre-cutover candidate, evidence and exact proposed transition to CORE6-06-V. Stop without changing ordinary authority. C19's actual transition/post-cutover proof remains pending by design; this primary's acceptance means complete candidate delivery, not an already enabled installation. The verifier must establish independent pre-cutover acceptance and genuine separately scoped cutover permission before any transition. Never leave two ordinary authorities, auto-merge, use project code to invoke platform completion, or reset prior history.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Complete Core coverage | Every retained C01-C20 requirement has current applicable independent evidence | Original/resolved matrix, actual current sources/host boundaries and renewed affected reports; installer summaries alone insufficient |
| Real caller readiness | Required checked and independent callers each have real bounded two-run evidence under their own authority | Actual IDs/decision/caller/run/native report references; fixtures and external unknowns never called accepted |
| Live non-reuse/writer safety | Actual current restore and installed final-writer proof remain applicable; uncertain owned work excluded | Actual drill/race/lifecycle records bound to current installed inputs, not old PASS labels |
| Singular authorized cutover | Exactly one ordinary authority after real prior-governance consent and accepted preconditions | Authentic scoped transition reference, actual fenced old/new state and checked post-cutover results; partial/unknown writes remain blocked |
| Final truthful assessment | Verified Core only when all applicable retained outcomes accepted; full v4 not claimed | Independent final report with fixed expected/raw outcomes, exclusions, cooperative limitations and unresolved owner/actions; platform lifecycle separate |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-06-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

The integration and prior-governance owners supply actual real caller/transition routes and scoped cutover permission. Required missing caller, writer, restore, containment or adoption proof blocks readiness. Preserve partial state and exact reconciliation action; no automatic recovery, repeat cutover, policy self-approval or fictitious full-v4 compliance. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-06-I. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Actual executable validation is pending this task's separate approval and verified prerequisites. Resolve the exact registered tier or bounded bootstrap/recovery capability, actual command/selectors/transitive graph, authentic bound decision, independently approved effective finite values and remaining allowance before dispatch. Use the accepted safe carrier; no invented default timeout or generic shell authority. Missing authority, containment, logging, actual proof or independent acceptance blocks the affected readiness claim.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Complete Core coverage; Real caller readiness; Live non-reuse/writer safety; Singular authorized cutover; Final truthful assessment; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-cutover.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Every retained C01-C20 requirement has current applicable independent evidence; Required checked and independent callers each have real bounded two-run evidence under their own authority; Actual current restore and installed final-writer proof remain applicable; uncertain owned work excluded; Exactly one ordinary authority after real prior-governance consent and accepted preconditions; Verified Core only when all applicable retained outcomes accepted; full v4 not claimed. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-cutover.test.mjs, and actual delivered source/test paths resolved before execution.


---

[REGRESSION-GUARD] Classification: security-privacy, data-integrity, concurrency-lifecycle, compatibility-contract. Guard: covered — scripts/test/failure-gate-core6-cutover.test.mjs.

# CORE6-06-V — Independently verify and repair: Accept the Core installation and authorize cutover

<!-- regression-guard: required -->

## Outcome and dependency

Owner: fresh independent verifier context, not the primary author's success statement. Declared stage: Fresh retained-scope real-caller acceptance; singular separately authorized ordinary transition. Requirement allocation: Every C01-C20 retained requirement. Semantic predecessor: CORE6-06-I. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Audit-first verification and scoped repair

1. Read the complete actual primary/verifier plans, adopted profile, current canonical closure and delivered inputs in this verifier's environment. Freeze the criteria below; independently resolve methods against installed wiring without deriving easier criteria from installer output.

2. Audit every assigned applicable outcome and publish the gap list BEFORE edits. Distinguish wrong/missing implementation, missing/stale proof and unavailable external authority. Record expected versus actual raw outcomes, evidence and verified/failed/blocked/justified-not-applicable status for every criterion.

3. Repair missing/wrong delivered implementation or scoped source/doc records within this approved pair's boundaries. Pair 06 may repair retained-scope omissions across the installation. No unrelated product fixes, hidden policy change, budget renewal, invented authority or extra tier execution.

4. Rebind repaired inputs and actual protected payload/decision through applicable amendment routes; invalidate affected evidence and renew required proof under genuine current limits. Correct expected denials/nonzero results are not bugs to repair to zero.

5. Obtain a fresh authorized independent post-repair readback/review with current evidence. A repair author's self-review is insufficient. Use an available independent host/fresh context route; do not recursively create tasks. If unavailable, mark acceptance blocked and propose the exact missing review route.

6. Record independent current pre-cutover acceptance of the delivered candidate, including renewed post-repair evidence. Until genuine separately scoped prior-governance cutover authorization is present, stop here with ordinary activation still pending. Neither this plan nor acceptance establishes cutover permission.

7. With that actual authorization and verified current safety prerequisites, perform the singular ordinary-authority transition through the real supported route and its specifically approved bounded post-cutover smoke proof. Reconcile unknown/partial writes before any retry. Interruption leaves ordinary dispatch blocked until authentic scoped recovery; no invented rollback grant or competing ordinary authority.

8. Obtain fresh independent post-transition acceptance with current inputs, records and actual smoke evidence; the transition author's self-review cannot pass this boundary. If the route is unavailable, report acceptance pending/blocked and the actual resulting authority state. Publish one final pair report and update the manifest/matrix with real evidence locators. Source is not runtime, bootstrap is not ordinary cutover, and administrative closure is not validation. No automatic successor, merge or deploy.

The primary scope audited by this verifier is included in full below; its fixed acceptance matrix is unchanged.

## Complete primary outcome scope

1. Reconcile the complete adopted Core version against current canonical/project instructions, source closure, actual implementation/wiring, accepted earlier matrices and current environment. Invalidate only affected evidence and renew it through real applicable authority; full-v4 exclusions remain visible.

2. Resolve remaining retained-scope omissions under approved overall installation scope. Preserve coverage, raw failures, original accounting and material amendment routes. Repaired inputs require renewed checks and fresh independent acceptance; do not fix unrelated app bugs.

3. Exercise every required retained local checked and genuine independent caller under its actual authority and verified finite containment. Use real local IDs/approved plans/current selected-tier reports for checked callers. Each enabled control/caller requires two consecutive real authorized runs within approved repetitions.

4. Verify current actual final-writer race, isolated restore/non-reuse, safe active/uncertain-run handling, durable telemetry and no excluded reclaim/remote dependency. Controlled denial fixtures do not replace these live proofs or authorize an all-tier sweep.

5. Prepare the exact singular ordinary-route transition under prior governance: version/scope, intended old/new authority, eligibility, quiescence, conflict fencing, migration, admission checks, evidence and fail-closed interruption/recovery. Do not silently turn bootstrap success or policy adoption into cutover consent.

6. Deliver the complete pre-cutover candidate, evidence and exact proposed transition to CORE6-06-V. Stop without changing ordinary authority. C19's actual transition/post-cutover proof remains pending by design; this primary's acceptance means complete candidate delivery, not an already enabled installation. The verifier must establish independent pre-cutover acceptance and genuine separately scoped cutover permission before any transition. Never leave two ordinary authorities, auto-merge, use project code to invoke platform completion, or reset prior history.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Complete Core coverage | Every retained C01-C20 requirement has current applicable independent evidence | Original/resolved matrix, actual current sources/host boundaries and renewed affected reports; installer summaries alone insufficient |
| Real caller readiness | Required checked and independent callers each have real bounded two-run evidence under their own authority | Actual IDs/decision/caller/run/native report references; fixtures and external unknowns never called accepted |
| Live non-reuse/writer safety | Actual current restore and installed final-writer proof remain applicable; uncertain owned work excluded | Actual drill/race/lifecycle records bound to current installed inputs, not old PASS labels |
| Singular authorized cutover | Exactly one ordinary authority after real prior-governance consent and accepted preconditions | Authentic scoped transition reference, actual fenced old/new state and checked post-cutover results; partial/unknown writes remain blocked |
| Final truthful assessment | Verified Core only when all applicable retained outcomes accepted; full v4 not claimed | Independent final report with fixed expected/raw outcomes, exclusions, cooperative limitations and unresolved owner/actions; platform lifecycle separate |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-06-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

The integration and prior-governance owners supply actual real caller/transition routes and scoped cutover permission. Required missing caller, writer, restore, containment or adoption proof blocks readiness. Preserve partial state and exact reconciliation action; no automatic recovery, repeat cutover, policy self-approval or fictitious full-v4 compliance. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-06-V. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Actual executable validation is pending this task's separate approval and verified prerequisites. Resolve the exact registered tier or bounded bootstrap/recovery capability, actual command/selectors/transitive graph, authentic bound decision, independently approved effective finite values and remaining allowance before dispatch. Use the accepted safe carrier; no invented default timeout or generic shell authority. Missing authority, containment, logging, actual proof or independent acceptance blocks the affected readiness claim.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Complete Core coverage; Real caller readiness; Live non-reuse/writer safety; Singular authorized cutover; Final truthful assessment; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-cutover.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Every retained C01-C20 requirement has current applicable independent evidence; Required checked and independent callers each have real bounded two-run evidence under their own authority; Actual current restore and installed final-writer proof remain applicable; uncertain owned work excluded; Exactly one ordinary authority after real prior-governance consent and accepted preconditions; Verified Core only when all applicable retained outcomes accepted; full v4 not claimed. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-cutover.test.mjs, and actual delivered source/test paths resolved before execution.
