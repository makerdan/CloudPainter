[REGRESSION-GUARD] Classification: data-integrity, concurrency-lifecycle, performance-reliability. Guard: covered — scripts/test/failure-gate-core6-bootstrap.test.mjs.

# CORE6-03-I — Implement: Prove the real bootstrap foundation

<!-- regression-guard: required -->

## Outcome and dependency

Owner: implementation context. Declared stage: Separately approved bounded bootstrap runtime; ordinary route disabled. Requirement allocation: C01, C06, C07, C08, C09 capture, C10 foundation, C11 bootstrap evidence, C16, C18. Semantic predecessor: CORE6-02-V, independently accepted with actual delivered inputs. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Implementation scope

1. Verify accepted delivered Pair 02 inputs and the actual adopted profile/current governance. Pin a fresh exact bootstrap operation/decision, approved source closure, command graph, environment and independently approved finite phase/parent/attempt values. Prior grants and remembered timeouts are not usable authority.

2. Before any stall/hang exercise, admit the first proof through an independently safe existing carrier. Establish actual registration/containment with controlled isolated workloads; do not require the future proof already passed to propose it, and do not run an uncontained experiment.

3. Under scoped permission, initialize/exercise the real local coordinator and prove concurrent committed uniqueness, audit rollback, CAS/idempotency, non-reuse and retained original accounting. Keep these isolated test identities distinct from production and platform task refs.

4. Prove the installed external supervisor against approved async/synchronous/hook/setup/teardown stalls, owner loss, watchdog loss, owned children, deadline/capture/storage failure and unknown acknowledgements. Preserve exclusion until actual stopped/quarantined evidence; never kill unrelated listeners.

5. Retain original intent/start/finish reports, raw status/signal, effective limits/consumption, clock lineage, registration/termination/capture evidence and expected-injected versus failed-acceptance distinctions.

6. Obtain two consecutive real authorized caller runs through the installed bootstrap route before enabled-bootstrap readiness claims, within genuinely approved repetitions and remaining limits. Register only the accepted bootstrap carrier; never ordinary activation/cutover.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Real admission | No workload before authentic scope, safe outer containment and registration | Actual operation/decision and provider registration records; flag/status/missing-provider paths must launch nothing |
| Real IDs | Concurrent committed allocation unique; cancelled/deleted identities not reused; audit failure rolls back | Actual isolated host store/transaction records, restart observations and raw selected fixture reports |
| Finite containment | Approved hangs terminate or remain explicitly quarantined within bounds; late zero never passes | Original independent supervisor and exact owned-tree evidence, including owner/watchdog loss and child survival negative cases |
| Capture/accounting integrity | Bounded output and typed acknowledgements; no new run ID or restart resets consumption | Raw overflow/uncertainty evidence plus original accounting; malformed acknowledgements never healthy release |
| Bootstrap readiness | Two consecutive real authorized installed-route caller runs, not just mocked fixtures | Actual separately identified caller/run evidence with current snapshot and approved repetitions; ordinary disabled |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-03-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

The bootstrap authority owner supplies an authentic fresh bounded decision; independent supervisor owner supplies verified safe containment. Insufficient remaining limits, unsafe containment or unknown owned-work state stops conflicting work, retains evidence/exclusion and produces an exact remediation/recovery proposal. No automatic rerun or counter reset. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-03-I. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Actual executable validation is pending this task's separate approval and verified prerequisites. Resolve the exact registered tier or bounded bootstrap/recovery capability, actual command/selectors/transitive graph, authentic bound decision, independently approved effective finite values and remaining allowance before dispatch. Use the accepted safe carrier; no invented default timeout or generic shell authority. Missing authority, containment, logging, actual proof or independent acceptance blocks the affected readiness claim.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Real admission; Real IDs; Finite containment; Capture/accounting integrity; Bootstrap readiness; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-bootstrap.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** No workload before authentic scope, safe outer containment and registration; Concurrent committed allocation unique; cancelled/deleted identities not reused; audit failure rolls back; Approved hangs terminate or remain explicitly quarantined within bounds; late zero never passes; Bounded output and typed acknowledgements; no new run ID or restart resets consumption; Two consecutive real authorized installed-route caller runs, not just mocked fixtures. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-bootstrap.test.mjs, and actual delivered source/test paths resolved before execution.
