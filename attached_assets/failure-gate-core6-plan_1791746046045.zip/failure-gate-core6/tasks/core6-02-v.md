[REGRESSION-GUARD] Classification: data-integrity, concurrency-lifecycle, performance-reliability. Guard: covered — scripts/test/failure-gate-core6-foundation.test.mjs.

# CORE6-02-V — Independently verify and repair: Stage Task IDs and the safe foundation

<!-- regression-guard: required -->

## Outcome and dependency

Owner: fresh independent verifier context, not the primary author's success statement. Declared stage: Inert source/schema/test authorship only. Requirement allocation: C01, C02, C03, C06, C07, C08, C10, C15, C16, C18. Semantic predecessor: CORE6-02-I. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Audit-first verification and scoped repair

1. Read the complete actual primary/verifier plans, adopted profile, current canonical closure and delivered inputs in this verifier's environment. Freeze the criteria below; independently resolve methods against installed wiring without deriving easier criteria from installer output.

2. Audit every assigned applicable outcome and publish the gap list BEFORE edits. Distinguish wrong/missing implementation, missing/stale proof and unavailable external authority. Record expected versus actual raw outcomes, evidence and verified/failed/blocked/justified-not-applicable status for every criterion.

3. Repair missing/wrong delivered implementation or scoped source/doc records within this approved pair's boundaries. Pair 06 may repair retained-scope omissions across the installation. No unrelated product fixes, hidden policy change, budget renewal, invented authority or extra tier execution.

4. Rebind repaired inputs and actual protected payload/decision through applicable amendment routes; invalidate affected evidence and renew required proof under genuine current limits. Correct expected denials/nonzero results are not bugs to repair to zero.

5. Obtain a fresh authorized independent post-repair readback/review with current evidence. A repair author's self-review is insufficient. Use an available independent host/fresh context route; do not recursively create tasks. If unavailable, mark acceptance blocked and propose the exact missing review route.

6. Publish one final pair report and update the single manifest/matrix with real evidence locators. Accept only the declared stage: source is not runtime, bootstrap is not ordinary cutover, and administrative closure is not validation. Do not prepare or run the successor in this task.

The primary scope audited by this verifier is included in full below; its fixed acceptance matrix is unchanged.

## Complete primary outcome scope

1. Reuse the discovered appropriate local transactional store and host-language tooling. Author schema/migrations for a unique namespace, committed reservations, permanent tombstones, one task row/tier assignment, plan/decision bindings, CAS/idempotency and atomic mutation-with-audit.

2. Preserve existing committed identities/history. Stage reconciliation/import and fencing rules rather than deleting old state, renumbering or restarting the allocator. A platform task number is never local authorization.

3. Stage operation/run records, retained original accounting, atomic single-flight and cross-task resource primitives, queue revalidation and denial defaults. Track active/terminal/suspended states and prevent concurrent transition/launch races.

4. Author approved-budget source validation, safe finite representations, aggregate bounds, original parent deadline/consumption lineage and reserved cleanup/capture. Do not invent actual approved values or refund started failed/cancelled attempts.

5. Stage a real-provider adapter boundary for independent whole-entry supervision, private workload-gate registration before dispatch, exact owned children, bounded reads/capture and truthful typed termination/storage acknowledgements. Missing provider denies launch.

6. Stage restart/backup/restore and retained-error recovery rules: post-backup ID reconciliation, old-writer fencing, true/unfinalized/missing-field uncertainty retained, exact separately approved recovery acknowledgement. Author foundation and bootstrap fixture/guard sources; do not execute them or initialize the store.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| C01 permanent identities | Source enforces committed uniqueness, namespace and non-reuse across cancellation/deletion/import | Inspect actual constraints/transaction boundaries and authored race/restart/tombstone cases; actual allocation at 03, restore at 05 |
| C02/C03 authoritative bindings | One task assignment, versioned plan/decision and atomic audit; no competing editable allow lists | Actual source and negative stale/version/wrong-project/audit-failure cases |
| C06-C08 safe dispatch | Unproven/missing registration, invalid limits or uncertain child state denies dispatch/release | Complete adapter/gate/capture source and authored stall/late-zero/overflow/unknown-ack cases; runtime explicitly deferred to 03 |
| C10 coordination | Single-flight and resources retain exclusion until owned work is stopped or quarantined | Actual source for concurrent reservation, transition races and interrupted accounting |
| C15/C16 recovery | No state restore or recovery can reuse IDs, reset budgets or silently clear uncertainty | Inert restore/fencing/acknowledgement source and fixtures; actual isolated restore at 05 |
| Source-only exit | Complete inert implementation accepted only as source, without operation/store claims | Independently inspected actual delivered source/migrations; no imports/guards/tests/build/CLI/store launch |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-02-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

Storage and independent-supervisor integration owners supply real supported persistence/containment. Finish permitted source where possible. Before Pair 03 dispatch, missing authentic authority, effective limits or independent safe containment blocks the proposed proof; it cannot be replaced with a same-loop timer. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-02-V. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Source/document readback and inert source/test authorship only. No imports, syntax/type checks, tests/guards, builds, package commands, CLI/store initialization, runtime wiring or signals. Later live proof is explicitly assigned to Pairs 03-06; source-stage acceptance cannot stand in for it.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** C01 permanent identities; C02/C03 authoritative bindings; C06-C08 safe dispatch; C10 coordination; C15/C16 recovery; Source-only exit; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-foundation.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Source enforces committed uniqueness, namespace and non-reuse across cancellation/deletion/import; One task assignment, versioned plan/decision and atomic audit; no competing editable allow lists; Unproven/missing registration, invalid limits or uncertain child state denies dispatch/release; Single-flight and resources retain exclusion until owned work is stopped or quarantined; No state restore or recovery can reuse IDs, reset budgets or silently clear uncertainty; Complete inert implementation accepted only as source, without operation/store claims. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-foundation.test.mjs, and actual delivered source/test paths resolved before execution.
