[REGRESSION-GUARD] Classification: compatibility-contract. Guard: covered — scripts/test/failure-gate-core6-source.test.mjs.

# CORE6-01-V — Independently verify and repair: Reconcile scope and current discovery

<!-- regression-guard: required -->

## Outcome and dependency

Owner: fresh independent verifier context, not the primary author's success statement. Declared stage: Discovery and inert source proposal; no runtime. Requirement allocation: C04, C17, C18, C20; allocate every C01-C20 requirement. Semantic predecessor: CORE6-01-I. Actual native dependency/readiness must be obtained through real interfaces; no fabricated task ref.

## Binding, authority and shared limits

Target: Custom Skills Workbench, https://github.com/makerdan/Custom-Skills-Workbench. Proposal identity: Custom-Skills-Workbench/failure-gate-core6/proposal-v1; inspected project snapshot 3473b2c76f0f450fbbc9a0b73efef80704507e45. Reconfirm identity and current controlling sources before use. This file is a complete proposed payload, NOT a created/approved/executed task. Platform task reference, local Gate ID, finalized revision/key/dependency, actual decision/grant, selected tier and independently approved budget values are UNASSIGNED. Never substitute this planning label or a Replit task number for a project-local authorization ID.

The proposed Core profile retains C01-C20, but excludes automated progression, pre-existing/unrelated process reclaim, catalog/ignore acceptance, auxiliary diagnostics/flakiness/provenance/comparison dispatch, export/import, automated pruning and remote/distributed dispatch. Do not claim full v4 compliance or silently waive the unchanged full contract. Adopt the scoped profile and reconcile conflicting instructions through actual authority before reduced-profile execution. Bootstrap, policy adoption, recovery and ordinary cutover are separate decisions. Owned-work termination under its original grant and actual safe restore/non-reuse remain required.

Preserve prior committed IDs/tombstones, native tasks, historical plans/reports, failures/repairs and consumed accounting. Reuse only independently supported current evidence. No old PASS, grant or owner closure establishes new acceptance. Every fixed outcome is independent of coding methods: routine in-scope programming needs no choice ledger or diary; material acceptance/scope/authority/safety/governing-plan changes use actual authorized amendment and fresh affected bindings.

Only the authorized tier or named bounded bootstrap/recovery capability may launch. Pin the actual argv/roots/hooks/config branches/children and verify coverage, authentic decision and finite input/queue/step/startup/test/hook/teardown/termination/capture/parent limits before dispatch. Independently supervise the whole approved local tree; register before user dispatch; bound capture and verify typed stop/storage acknowledgements. No remote launches, unknown expansion, arbitrary passthrough, all-tier sweep, hidden retry, budget enlargement/reset, unhealthy-log fallback or unsafe hang experiment. Admission expiry does not abandon already owned work; uncertain lifecycle or recovery retains exclusion. Preserve genuine independent callers and their own coverage/authority without task metadata; their evidence never substitutes for a checked task run.

## Native handoff, delivery and advancement

Materialize only after separate authorization through verified actual task interfaces. Reconcile existing current/legacy tasks and partial/unknown writes before creating; an unknown timeout is not rollback. Use actual returned refs and normalized project/primary/finalized-plan/scope duplicate bindings. Confirm primary committed/finalized full readback before attaching its verifier; independently verify real dependencies and complete verifier payload. A dependency, title, Ready/Done/Merged label, digest metadata or source-file presence alone proves neither delivery nor acceptance. Check accessible actual inputs and re-read full plans around linkage, execution and report acceptance. No replacement for a running/unaccepted obligation, terminal-task reopening or lifecycle rewrite.

At most one unfinished pair is current; later pairs remain backlog. A successor needs independently accepted current declared stage, actual accessible delivered inputs and applicable authorization. Resume on explicit invocation; no hook, polling, auto-approval/start/merge/deploy. Disposable .local submission copies are permitted only under actual applicable host-required-path authority with a complete authoritative tracked copy preserved/read back first; never initial drafting, sole copies, final deliverables or canonical sources. These files do not override separate workspace prohibitions.


## Audit-first verification and scoped repair

1. Read the complete actual primary/verifier plans, adopted profile, current canonical closure and delivered inputs in this verifier's environment. Freeze the criteria below; independently resolve methods against installed wiring without deriving easier criteria from installer output.

2. Audit every assigned applicable outcome and publish the gap list BEFORE edits. Distinguish wrong/missing implementation, missing/stale proof and unavailable external authority. Record expected versus actual raw outcomes, evidence and verified/failed/blocked/justified-not-applicable status for every criterion.

3. Repair missing/wrong delivered implementation or scoped source/doc records within this approved pair's boundaries. Pair 06 may repair retained-scope omissions across the installation. No unrelated product fixes, hidden policy change, budget renewal, invented authority or extra tier execution.

4. Rebind repaired inputs and actual protected payload/decision through applicable amendment routes; invalidate affected evidence and renew required proof under genuine current limits. Correct expected denials/nonzero results are not bugs to repair to zero.

5. Obtain a fresh authorized independent post-repair readback/review with current evidence. A repair author's self-review is insufficient. Use an available independent host/fresh context route; do not recursively create tasks. If unavailable, mark acceptance blocked and propose the exact missing review route.

6. Publish one final pair report and update the single manifest/matrix with real evidence locators. Accept only the declared stage: source is not runtime, bootstrap is not ordinary cutover, and administrative closure is not validation. Do not prepare or run the successor in this task.

The primary scope audited by this verifier is included in full below; its fixed acceptance matrix is unchanged.

## Complete primary outcome scope

1. Read and pin current canonical .agents sources and applicable references; verify project/root/origin and current governing instructions. Reuse the existing discovery and independent observations for their supported snapshots, not their native lifecycle labels.

2. Compare the changed orchestration source against the blocked Piece 01 assessment. Identify affected requirements, actual controlling-version authority and necessary narrow renewal. Preserve unaffected supported facts and all historical ledgers/readbacks.

3. Publish one reduced-profile manifest and C01-C20 fixed outcome matrix. Map retained requirements to real source/installed boundaries and later proof gates. Explicitly mark the full-v4 capabilities removed/deferred, including the no-ignore failure policy.

4. Inventory real commands, tiers/coverage, independent callers, local store/IDs, writer coverage, approval sources and supervisor capabilities. Check reclaim-dependent aliases and deny unsupported remote dispatch. Inspect only through permitted read routes; do not initialize stores or infer current state from old documents.

5. Prepare concrete profile-adoption and first-proof proposals with actual owner routes, bounded scope and missing providers; record adoption only if genuinely obtained. Propose a versioned deterministic activation policy if no applicable approved policy exists. Profile adoption, bootstrap execution and ordinary cutover are distinct decisions.

6. Author the named inert source guard for complete six-pair/twelve-payload retention, excluded scope and no borrowed authority. No import, syntax check or test launch.

## Fixed acceptance matrix

| Criterion | Fixed expected outcome | Required proof / negative boundary |
|---|---|---|
| Current discovery | Project and sources are accurately bound; unrelated historical evidence retained | Actual readbacks and current/frozen differences; no invented namespace or current-store state |
| Fixed reduced contract | All C01-C20 outcomes remain covered; full-v4 exclusions expressly visible | Source-to-requirement matrix plus profile proposal; omission of Task ID non-reuse must reject |
| Authentic authority | Real adoption status and routes distinguished from proposals | Actual decision reference if present; missing adoption/approval remains pending, not approved |
| Dependency exclusions | No retained route silently requires deferred reclaim or remote dispatch | Actual alias/consumer graph and scoped remediation proposal; unavailable provider alone never N/A |
| Source-stage exit | Accurate complete proposal may accept as source/discovery; no runtime readiness | Inert guard source and independent current-source assessment; later authority blockers have named owner/action |

For every row retain fixed expected/allowed outcome, actual observed result, source/implementation/environment binding, raw evidence reference, status and responsible next action. Shared evidence may serve multiple mapped criteria. Correct negative fixtures satisfy only their declared case; missing required live proof remains BLOCKED/NOT_RUN.

## Deliverables and report

Use the single installation manifest/evidence index and C01-C20 matrix at the later authorized project destination docs/validation/failure-gate-core6/. Primary handoff fields include actual delivered snapshot, changed paths, source/authority/limit bindings and unresolved gates; no duplicated installer diary is required. This pair's final report destination is docs/validation/failure-gate-core6/pair-01-acceptance.md (proposed, not installed). Retain actual code/schema/native reports/raw records where host policy requires; sanitize secrets.

## Blocked/resume route

The canonical-source/profile owner must resolve controlling-version authority and any conflicting full-v4/project scope before reduced-profile execution. The discovery custodian renews affected records; the integration custodian supplies actual approval/supervisor routes. Do not restart unrelated discovery or duplicate the old primary. Continue independently permitted nonconflicting work. At a real boundary prepare the smallest concrete proposal: current source/plan bindings, actual authority owner/route, missing capability/input, permitted command graph or NONE, effective finite limits/remaining consumption or UNESTABLISHED, safety/admission, exact acceptance proof and exclusions. A proposal authorizes no task, launch, renewal, recovery, cutover or publication.

## Task identity

Planning label: CORE6-01-V. Actual platform ref/namespace/dependency/key/finalized digest: UNASSIGNED. Actual local Gate task or approved operation identity: NONE allocated by this proposal. Local task allocation may occur only through a genuinely authorized applicable allocator route; bootstrap/planning use their actual distinct operation identity and cannot invent an active local task.

## Pre-existing failures to ignore

None authorized. Initial Core has no ignore catalog or exception acceptance. Preserve actual historical failures and owned repairs. A passing retry proves neither provenance nor permission to ignore a failure; unresolved retained failures block validated completion.

## Task-local environment observations

Project source was inspected at 3473b2c76f0f450fbbc9a0b73efef80704507e45. No store, runtime, caller or budget state was probed by this proposal. Historical STAGED and the blocked Piece 01 source assessment are observations, not current execution authority. Reconfirm present state through permitted evidence before action.

## Validation

Source/document readback and inert source/test authorship only. No imports, syntax/type checks, tests/guards, builds, package commands, CLI/store initialization, runtime wiring or signals. Later live proof is explicitly assigned to Pairs 03-06; source-stage acceptance cannot stand in for it.

All named tests are prospective authoring targets, not tests asserted to exist or pass. Fit them into the actual authorized retained coverage without tier escalation. Record raw failures/signals/expected injected outcomes and real host evidence separately from fixtures. Source/version/repair changes renew only affected applicable proof, without erasing history. No checks ran while writing this payload.

## Regression Guard

**Covers:** Current discovery; Fixed reduced contract; Authentic authority; Dependency exclusions; Source-stage exit; scoped changes must not lose their fixed expected outcomes, current evidence or authority/lifecycle boundaries.
**Test location:** scripts/test/failure-gate-core6-source.test.mjs — proposed host-boundary regression source, authored within this pair's approved scope; actual paths/runner mapping resolved against delivered host wiring before use.
**What it checks:** Project and sources are accurately bound; unrelated historical evidence retained; All C01-C20 outcomes remain covered; full-v4 exclusions expressly visible; Real adoption status and routes distinguished from proposals; No retained route silently requires deferred reclaim or remote dispatch; Accurate complete proposal may accept as source/discovery; no runtime readiness. Assert the negative cases at the actual owning boundary, not only counts/digests or installer labels. Source-only stages author concrete cases but execute nothing; actual bootstrap, writer-race, restore and caller proofs remain at their declared later gates.

## Relevant files

- .agents/skills/failure-gate-v4/SKILL.md and applicable canonical reference closure.
- .agents/skills/paired-task-orchestration/SKILL.md and complete applicable references.
- .agents/skills/skill-application-router/ canonical full-plan/binding/recovery/delivery rules.
- .agents/skills/regression-guard/SKILL.md and current replit.md.
- Existing failure-gate discovery/source-review history and actual scripts/failure_gate/ tooling discovered in the selected project.
- Adopted Core profile, current manifest/matrix, actual prior pair evidence, proposed guard scripts/test/failure-gate-core6-source.test.mjs, and actual delivered source/test paths resolved before execution.
