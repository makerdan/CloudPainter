# Port Authority — authoring readback and verification boundary

## Delivered scope

Updated the supplied canonical Port Authority package under
`.agents/skills/port-authority/` in this conversation. Only `SKILL.md` and
`reference/runtime-contract.md` were amended. The four runtime scripts and
existing test suite remain byte-identical to the uploaded originals, with
their original file modes restored/preserved.

Added criteria-based handling of expected BLOCKED/BLOCKING/negative/non-zero
results at the global rule and individual phase decision points. Genuine missing
authority, source integrity, implementation, coverage, budget or required evidence
still blocks the affected operation. Correct negative behavior must not be repaired
to obtain zero; raw findings remain distinct from criterion/task acceptance.

Moved the existing validation-registration table, resource examples and migration
detail to the complete runtime reference, preserving those obligations and adding
resolving links. The entry point remains below its existing 500-line limit.

Created two separate companion artifacts:
- `port-authority-paired-installation-series.md`: 14 ordered implementation and
  independent verification-and-scoped-repair payloads, with one current draft pair,
  a full shared task contract and source/fixture/real-host stage separation.
- `port-authority-package-usage.md`: definition-only installation, project binding,
  conditional drafting and invocation-driven resumption instructions.

These artifacts are outside the seven-file canonical package, not extra runtime
dependencies or auto-created native tasks.

## Checks actually performed

| Check | Actual outcome |
|---|---|
| Existing documentation-policy tests | 5 passed, 0 failed, 0 cancelled; run twice as read-only selections after edits |
| Package closure | Exactly the 7 expected canonical files |
| Frontmatter/size | Name valid, description within its existing 1024-character limit; 495 logical lines and existing below-500 test passes |
| Markdown links | All package-relative paths and heading anchors resolve |
| Runtime/test parity | All 4 runtime scripts and the test suite byte-identical to original ZIP members |
| File modes | All 7 match supplied ZIP metadata, including executable cleanup/lock scripts |
| JavaScript syntax | All 5 unchanged JavaScript files pass Node syntax checks |
| Series structure | 14 ordered pieces; 14 complete primary and 14 verifier payload sections |
| Shared task requirements | Expected outcomes, full-plan readback/delivery, approval boundaries, bounded validation, Regression Guard, audit-first scoped repair and independent post-repair acceptance are present |
| Phase coverage | Original Phases 0–9, independent all-entry-point budgets and migration remain covered |

The read-only policy command was:

```sh
timeout --kill-after=3s 20s node --test \
  --test-name-pattern='^(skill:|policy)' \
  .agents/skills/port-authority/tests/hardening.test.mjs
```

This selection executes the five source/documentation-policy tests, not the
process/port/lease runtime fixture suite. No fixture adapters were installed.
Node version observed for these authoring checks: v24.13.0.

## Observed current package manifest

These SHA-256 values bind observed delivered content. They are not supplied trusted
checksums, a human approval, host attestation or runtime acceptance evidence.

| Canonical-relative path | SHA-256 |
|---|---|
| SKILL.md | 0bac582691247466ed70d3360861e51ddbdddef3ee87a0edb77d72464952636c |
| reference/runtime-contract.md | 4cefa6b699934148d2de707738c6d65f0f096b0ed701f6576d822f4581d3e1f1 |
| scripts/free-ports.mjs | d31d5817fe4635e7e586631be91846cc26ba6683337399d2b969b1fd223cda4f |
| scripts/host-capabilities.mjs | cde66e139ecbb541f168edf34adbf6583369fd14e6c0590b9f67716fc0514061 |
| scripts/runtime-environment.mjs | ded3050e2f4505bfc192378ae031f059ba0d6361f1ea3a4c0b7f36beb40bfc4e |
| scripts/validation-lock.mjs | d819f38df10b914751471066e36239d843cdbfd3aaa5540563047f9ca49797bb |
| tests/hardening.test.mjs | 3681a1286b418e0d4efd68f58f51fef79b897f3b3ed21197681383fa5227b054 |

## Unperformed and unverified

No target project was bound or substantively inspected. No native tasks were
created, approved, executed or completed. No runtime callers, workflows, services,
ports, live leases, production flags, host provider, approval registry, remote CI,
schedule, hook, merge or deployment were changed.

The full isolated adversarial runtime suite was NOT run. Real host validation,
independent target verification, task API/delivery semantics, concurrency,
automatic wake-up, trusted provider integration, live reclaim, actual lock wiring,
browser/API health and final twice-run host acceptance were NOT performed.
Static authoring checks establish source/document structure and unchanged runtime
content, not deployed enforcement or elimination of false blockers in live Agent.

This is authoring readback, not independent project acceptance. Workspace skill
publication and installation into another project remain separate operations.
Before native materialization, bind the actual project, approved scopes, complete
canonical contracts, task interfaces and required confirmation batching.
