# Port Authority — paired installation and verification series

## Status and scope

This is a complete planning backlog, not native task creation, approval, execution,
an initialized project series or operational installation. No target project is
bound. `PA-01-I` through `PA-14-V` below are specification labels, NOT native IDs.
Resolve real project/task identities and authorized task plans before writing cards.

Baseline: the updated canonical seven-file package at
`.agents/skills/port-authority/`, including its complete runtime contract. Keep the
original uploaded package, amended sources, observed digests and task specification
as distinct immutable baselines when binding a host. Digests establish content
identity, not trust or authority. Never use a disposable mirror as canonical input.

The series has **14 ordered pieces**, each with one implementation primary and one
independent verification-and-scoped-repair payload. Later pieces remain durable
backlog. Prepare only the earliest eligible unfinished pair as proposed tasks under
actual user permission; do not create all 28 cards or approve/start any automatically.

Definition-only installation is not series initialization. Installing this document
does not authorize task preparation, tests, repairs, activation, disruption, recovery,
policy changes, remote CI, merge, deployment, recurring work or hook installation.

## Stage and ordering contract

| Piece | Scope | Declared acceptance stage |
|---|---|---|
| 01 | Project binding, Phase 0 audit, expected-outcome map | Evidence-backed discovery/planning |
| 02 | Canonical package integrity and inactive staging | Source/package staging only |
| 03 | Validation registration and finite execution routes | Source/readiness mapping, not executed host proof |
| 04 | Isolated mandatory bundle matrix | Bounded isolated regression evidence only |
| 05 | Phase 1 process/workflow discipline | Staged host adaptations |
| 06 | Phase 2 cleanup inventory and guards | Staged non-reclaim implementation |
| 07 | Phase 3 browser/e2e startup | Conditional staged adaptation |
| 08 | Phase 4 serialization and resource graph | Conditional staged adaptation |
| 09 | Phase 5 generated-file protection | Conditional staged adaptation |
| 10 | Phase 6 test hygiene and evidence policy | Staged applicable safeguards |
| 11 | Phase 7 WebSocket/HMR lifecycle | Conditional staged adaptation |
| 12 | Phase 8 real API/browser health contract | Staged probes and permitted isolated regressions |
| 13 | Independent providers, development exception and live reclaim | Conditional actual capability/caller acceptance |
| 14 | Phase 9 actual host cutover, repeatability and migration | Actual authorized host acceptance |

The independent all-entry-point budget gate is addressed before execution in
Pieces 03–04 and retained in EVERY later piece, including when serialization is
not applicable. The numbered runtime phases retain their relative order.
Live reclaim/development-exception activation is deferred to Piece 13; actual
caller/config/workflow activation is deferred to separately approved Piece 14.

Pieces 05–12 stage proposed runtime/configuration changes in inactive locations
and retain host assertions for Piece 14. Do not call this installed wiring or
fixed production behavior. Isolated proof may be collected only through an
actually authorized finite route; source preparation need not fabricate host
proof. If the approved task requires runtime acceptance earlier, honor that
scope instead of silently converting it to staging.

A conditional piece can be accepted as justified not applicable only after its
gate is genuinely false in the bound project. Missing permission/provider/evidence
is BLOCKED, not not applicable. If a selected live-reclaim prerequisite remains
unmet at Piece 13, retain that obligation; do not silently skip to Piece 14.
An explicitly approved scope revision may select a non-reclaim installation,
preserving deferred live-reclaim work and its later acceptance gate.

## Shared contract — expand into EVERY native primary and verifier plan

### Binding, delivery and approval

Read the complete current primary/verifier payload, canonical package/reference
closure, authorized specification and actual project policy. Record real project,
series/piece/generation, native task namespace/ID, plan revision/digest, source
manifest, delivered snapshot, target stage, inputs, outputs and report destination.
Never materialize a title-only task or leave unresolved placeholders in its plan.

Use existing tracked host backlog/checkpoint/evidence locations outside `.local/`.
Example report layout: `artifacts/port-authority-series/reports/`; choose and bind
the actual host location before creation. These files are locators, not approvals,
validation registries, global locks or native completion APIs.

Where canonical paired-task-orchestration and Router contracts are applicable,
use their complete handoff protocol. No companion skill is automatically installed
or required merely by this package. A target-required missing contract remains
pending, never replaced with a mirror or an invented interface.

Search/reconcile existing tasks by authoritative bindings before creation.
Read the finalized complete primary back before linking the verifier, then read
the complete persisted verifier back. Require actual dependency semantics AND
delivered-input readiness in its environment. Resolve unknown commits and partial
pairs before retrying; do not replace running/blocked work or promise global
exactly-once creation without supported coordinator/idempotency evidence.

Check mandatory definition-confirmation versus resource/application verification
before native materialization. If target contracts require a SKILL.md-only
confirmation in addition to the package verifier, obtain the narrow visible
batching decision before extra cards; never merge away or hide that obligation.
No actual such target contracts or task APIs have been verified in this document.

### Outcome contract

Every acceptance item must state its expected/allowed result, required evidence,
actual raw code/state and assessment. Match against the declared task purpose,
not a default zero/PASS assumption or native Ready/Done/Blocked label.
Expected `BLOCKED`, `BLOCKING`, negative or non-zero outcomes may satisfy a task
only when its authorized criteria permit them and all other criteria are met.
Do not invent an expected outcome after failure or modify correct rejection
behavior to obtain zero. Retain raw findings, no-signal/no-dispatch observations,
termination/release evidence and genuine downstream blockers.

Typical distinctions to include where applicable:
- Invalid/prohibited input: expected exit 2 plus correct structured rejection.
- Protected busy or dry-run: expected exit 3, accurate inventory, no signals.
- Unknown discovery/checked authority: expected exit 4 and fail-closed behavior;
  a production-marked environment-admission denial instead follows exit 2.
- Normal child failure propagation: expected child exit 7 and healthy lifecycle
  release; not a claim that the child workload passed.
- Timeout/cancellation/recovery fixtures: expected bounded non-zero result plus
  the exact stopped-work/retained-exclusion assertions, not accepted real overrun.
- Health negatives: intended rejection of HTML-200/outage/malformed responses,
  not proof that the genuine API is healthy.

An expected inner failure passes when its assertions pass. An unexpected failed
assertion or outer suite non-zero remains failure. Fixtures never manufacture
genuine host attestation, human approval, successful cleanup or host readiness.
A completed finding task may expose a blocker for a later task without being
itself incomplete. Missing proof required by the current task still blocks it.

### Authorization and validation

Discover Failure Gate ACTIVE/INACTIVE/UNKNOWN status from actual canonical policy.
Active policy uses its checked task/approved-plan/tier/evidence routes.
Verified inactivity uses existing authorized host policy; UNKNOWN is not inactivity.
Do not impose Failure Gate on unrelated work or invent its API/approval registry.
Live reclaim always retains the contract's genuine host and checked authority
requirements regardless of general validation-policy status.

Select one actually authorized validation tier/command for each native task.
No automatic tier changes, coverage waivers, fake registrations or inherited
diagnostic permission. Every launch, fixture, retry, comparison, hook and nested
runner needs its own applicable finite queue/execution/cleanup/evidence and
parent/cumulative bounds with independent whole-tree supervision. Preserve
consumption, current-snapshot bindings and retained incidents; no deadline reset.
Use disposable fixtures only, never application ports/leases for negative tests.

Every native plan must contain:
- `## Pre-existing failures to ignore`: actual policy-qualified catalog matches
  and retained raw evidence, or an evidenced statement that no applicable ignore
  was established. A label does not waive coverage or an owned repair.
- `## Validation`: stage-specific checks, actual authorized route/tier, evidence,
  effective finite limits, negative expectations and deferred host acceptance.
- `## Regression Guard`: for material behavior/safety/lifecycle changes, identify
  the prior contract, smallest failing scenario, positive and negative regressions,
  affected transitive callers and evidence invalidated by repair. For genuinely
  source-only/discovery work, state the concrete reason no runtime guard applies.

### Full verifier routine — include in EVERY `PA-xx-V`

Freshly inspect the actual delivered implementation and bindings independently of
the primary author's success claim. Compare every applicable source clause and
piece acceptance item; list genuine gaps BEFORE edits. Mark each verified, failed,
blocked or justified not applicable, distinguishing expected negative results
from missing requirements. Do not demand future runtime proof for inert stages.

If the approved verifier task explicitly authorizes repair, correct missing/wrong
implementation within that piece only, then rebind snapshots and renew affected
authorized checks. Default read-only auditing is not repair permission. Without
repair authority, report/propose the exact repair route; do not change live callers,
install missing authorities or weaken production/coverage/budget guards.

Obtain genuinely independent post-repair review through an available authorized
fresh context or host review. Self-review is not independent acceptance; if that
required route is unavailable, retain the acceptance blocker without recursive
verifier-task creation. Record original and amended revisions, raw results, allowed
outcome matches, remaining incidents, dependencies, responsible roles and next action.
A scoped verifier approval is not blanket permission for extra tests or disruption.

## Piece 01 — Project binding, audit and outcome baseline

### PA-01-I — Bind the actual host and discover applicable phases

**Inputs/stage:** user-selected verified project identity, supplied canonical
package and approved discovery scope; read-only planning.

Inventory Phase 0 processes/ancestry, sockets, workflows/current limit evidence,
validation aliases/durations, shared ports/generated outputs/DB/CPU, browser
harness, pools, WebSockets/HMR, health contracts and current installed cleanup/
lock copies. Discover actual host runtime flags, Linux/Node/filesystem capability,
canonical governance and task/delivery interfaces. Do not signal or stop anything.

Record evidence, each base/conditional gate, desired per-control installation
scope, current ownership and legacy risks. Pin the full package/specification and
define expected-outcome/evidence mappings, source/runtime boundaries and deferred
prerequisites. Retain missing provider findings and explicit follow-up routes.

**Acceptance:** accurate evidence-backed inventory and gate/outcome matrix.
An absent harness/provider, workflow conflict or unsafe legacy finding can fulfill
discovery; it does not fulfill a later fix or activation requirement.

### PA-01-V — Verify discovery and repair authorized record omissions

Apply the full shared verifier routine. Reinspect actual inventories and policy/
project identities; challenge guessed gates, missing ancestry and title-only task
bindings. Check negative findings against source evidence and their declared
diagnostic purpose. Correct only approved discovery/backlog records, not runtime.
Accept when required discovery is complete; retain downstream capability blockers
and defer all tests/disruption lacking authority.

## Piece 02 — Canonical package integrity and inert staging

### PA-02-I — Stage the complete skill without replacing active wiring

**Inputs/stage:** accepted Piece 01, exact package manifest and approved staging
scope; source/package stage only.

Verify all seven canonical files, frontmatter, complete runtime reference, links
and actual file modes. Compare observed package digests with the pinned baseline;
do not invent trusted expected hashes. Audit existing source/runtime destinations.
Stage the canonical skill package and only needed runtime templates inertly,
placing both shared helpers beside each consumer. Preserve executable bits.
If a path is active, use an inactive authorized destination instead of overwriting.

Do not wire aliases/workflows/startup hooks, restart services, signal listeners,
delete leases, synthesize providers or run tests merely because files were placed.
Resolve target-required file-only confirmation/resource-verification batching
before task creation. Record source parity separately from test readiness.

**Acceptance:** complete verified canonical source placement and unchanged active
callers. Missing host reclaim authority may be a correct deferred finding, but
missing/corrupt required package files cannot satisfy this staging task.

### PA-02-V — Verify canonical definition/resources and repair staging gaps

Apply the full verifier routine to all seven delivered files, links, modes,
manifest and inactive placement. Check both helpers accompany each staged
consumer and no caller changed. Repair only approved staging omissions; preserve
active scripts. If separately required, keep SKILL.md-only confirmation distinct
from full resource review. Accept only STAGED scope; explicitly retain runtime/
isolated-check obligations. No fixture or source parity claim implies activation.

## Piece 03 — Registration, supervision and execution readiness

### PA-03-I — Bind validation routes and stage finite supervision

**Inputs/stage:** accepted Pieces 01–02, actual policy/runner sources and approved
source/adaptation scope; source and readiness mapping, not actual host acceptance.

Inventory every finite entry point including pre/post hooks, nested runners,
startup/teardown, diagnostics/retries/comparisons and remote work. Map executable
commands, assigned tiers and actual platform registrations where supported.
Preserve fast/standard/standard-plus/heavy distinctions only when that convention
exists. Missing optional checks must be explicit, not placeholders.

Stage required adaptations to the existing authorized runner: finite queue,
execution, cleanup/evidence and parent/cumulative boundaries; independent outer
supervision; effective Node test/hook limits; cancellation and owned-tree identity/
termination. Do not silently broaden limits or install another governance system.
Record capability readiness separately from proposed source. Bind a permitted
fixture route for Piece 04; unavailable execution authority keeps that later run
blocked without invalidating an otherwise complete source/readiness report.

**Acceptance:** complete entry-point route/limit manifest and staged implementation
or verified existing source for in-scope adaptations; no unbounded/exempt path is
called ready. Readiness findings may be negative, but invented supervision cannot
satisfy implementation requirements. Defer actual all-entry-point proof to Piece 14.

### PA-03-V — Verify routes, budgets and repair bounded-runner omissions

Apply the full verifier routine. Read transitive scripts/hooks and authoritative
limit sources; distinguish source configuration from real enforcement. Check
no serialization exemption, tier substitution, parent reset or direct-package
bypass. Repair authorized source gaps with Regression Guard; never create approval
or launch tests without their separate capability. Accept source/readiness scope
only with exact manifest and deferred-proof owners.

## Piece 04 — Isolated mandatory adversarial matrix

### PA-04-I — Exercise the canonical bundle in disposable fixtures

**Inputs/stage:** accepted source pieces, actually authorized finite isolated-test
route and supported Linux/Node capabilities; isolated regression evidence only.

Run the runtime contract's full mandatory bundle suite twice sequentially through
its supervised fixture mode and verified finite independent outer boundary.
Retain test/hook limits, execution/cleanup/parent limits, exact command/source
revision, raw reports, fixture identity and termination/exclusion evidence.
Never use real service ports or workspace leases; do not alter caller production
flags or replace the shipped host adapter with fixture authority.

Map every matrix assertion to the actual tested source, including exits 2/3/4,
child 7 propagation, no signals/dispatch on denial, retained uncertainty, watchdog/
deadlines and correct lifecycle behavior. The outer suite must pass assertions.
Do not run indefinitely, delete retained fixture state blindly or retry until green.

**Acceptance:** both complete bounded isolated suites and matrix evidence pass;
expected inner rejection/non-zero results satisfy their assertions. Missing test
permission or failed outer assertions genuinely block this piece. No host claim.

### PA-04-V — Verify raw fixture outcomes and repair only authorized bundle gaps

Apply the full verifier routine. Reconcile source/reports, completeness, actual
outer supervision and fixture-only authority. Do not mark the task BLOCKED merely
because valid denial outputs occurred. Unexpected assertion/lifecycle failures
are gaps; any authorized correction must preserve the runtime contract, rebind
sources and renew both affected complete runs within retained budgets.
Independent post-repair acceptance is required. Carry all host gates to Piece 14.

## Piece 05 — Process discipline and workflow pressure

### PA-05-I — Stage managed-process and workflow corrections

**Inputs/stage:** Phase 1 audit and accepted earlier pieces; staged adaptations.

Prepare in-scope corrections so persistent services/watchers use actual managed
workflows, not nohup/setsid/ad-hoc background shells. Distinguish finite validation
from servers, preserve task-risk tiers and route services through authoritative
distinct port mappings. Inspect preview routing before changing ports.

For evidenced pressure, stage budgeting/consolidation using real platform limits,
reserve scarce slots for persistent work and preserve applicable tier distinctions.
For stale counters, allow only the contract's bounded wait/one retry under actual
permission; contradictory capacity is a finding, not permission for an endless
loop. Do not delete unrelated workflows, wire/restart callers or bypass caps.

**Acceptance:** staged configs/commands and evidence-backed gates, with Regression
Guard for process lifecycle, ports and validation coverage. A valid capacity
rejection can complete its diagnostic item, not a missing config correction.

### PA-05-V — Verify discipline and repair source/config omissions

Apply the full verifier routine. Check all persistent callers, authoritative port
bindings, actual limit evidence, consolidation scope and finite validation routes.
Repair only approved inactive config/source; verify unrelated workflows untouched.
Match expected capacity diagnostics separately from required staged corrections.
Retain managed-workflow/restart/preview host proof for Piece 14.

## Piece 06 — Cleanup discovery, guards and non-reclaim source

### PA-06-I — Adapt one audited cleanup implementation safely

**Inputs/stage:** Phase 2 requirements, ownership/port audit, staged canonical
helpers and approved adaptation scope; non-reclaim source stage.

Reuse/adapt the audited existing cleanup or canonical template. Preserve socket
inode/PID discovery, complete applicable TCP evidence, caller ancestry/own-tree
protection, recursion/disable/production guards, exact incarnation/boot binding
and structured FREE/FAILED/INVALID/PROTECTED/UNKNOWN states. Stage both helpers.

Default to dry-run. Retain the exact v2 manifest, task/plan/run binding, checked
claim/rechecks/outcome acknowledgement, no inferred descendant permission and
bounded TERM/KILL verification contract for future action. Document Linux/
cooperative limitations and startup reservation needs; no fuser dependency.
Do not implement fake host authority or enable live signals in this piece.

**Acceptance:** complete staged cleanup/source contract and permitted isolated
positive/rejection proof. Expected exits 2/3/4 preserve non-success states and
no-signal evidence; they can satisfy negative checks, never imply FREE.
Actual provider/reclaim requirements remain explicitly owned by Pieces 13–14.

### PA-06-V — Verify discovery/denials and repair authorized source gaps

Apply the full verifier routine. Check structured outcomes and unchanged protected
targets, no authorization inferred from names/ports/ancestry/JSON, unavailable
adapters retained fail-closed and production markers preserved. Repair only
approved source; never invoke live cleanup to finish verification.
Require Regression Guard for admission/ownership/discovery/termination changes.
Accept staged scope, preserving real activation prerequisites.

## Piece 07 — Browser/e2e startup, if applicable

### PA-07-I — Stage harness startup and init-script corrections

**Inputs/stage:** verified Phase 3 gate, discovered real harness startup order
and source-stage predecessors; conditional inactive adaptation.

If absent, record evidence-backed not applicability without inventing Playwright.
If present, stage guarded cleanup in each appropriate webServer startup command,
not globalSetup after servers have started; config-load cleanup needs verified
ordering and guards. Pass addInitScript values explicitly through serialization.
Record any transitive reclaim dependency and keep caller activation gated on
genuine authority. Do not remove a required safety dependency to make it runnable.

**Acceptance:** correct staged wiring/order, explicit value transport, Regression
Guard for startup safety and permitted fixtures. Expected guarded rejection can
pass its negative check, not demonstrate usable actual startup.

### PA-07-V — Verify harness gating and repair startup source omissions

Apply the full verifier routine. Re-read actual harness/config aliases, confirm
ordering and carried values, and verify valid skip evidence if no harness.
Repair only approved inactive startup/init code; no killing fresh real servers.
Accept source scope with usable-host-startup and provider gates retained for final
acceptance; unavailable capability is not an absent-harness excuse.

## Piece 08 — Serialization, resource identities and lease lifecycle

### PA-08-I — Stage complete conflicting-caller serialization

**Inputs/stage:** actual Phase 4 conflict gate and accepted foundations;
conditional staged implementation.

If gate is false, preserve finite supervision without unnecessary locks.
Otherwise adapt existing audited lock or canonical v2 template and stage every
conflicting alias, pre/post hook, nested runner and workflow through the SAME
canonical resource identity or verified common acquisition order. Record override
paths, one-resource-per-invocation limits, nonhierarchical global/composite names
and advisory priorities in the caller-to-resource conflict map.

Preserve path/token/boot/incarnation/ancestor-bound reentry, sibling serialization,
independent pre-dispatch registration, remaining budgets and raw child propagation.
Retain uncertain/error leases and sidecars; no heartbeat/age-based stealing,
PID-only legacy reuse, daemonization or blind unlink. Inspect real transitive scope.

**Acceptance:** complete staged wiring, contract and Regression Guard. Authorized
fixtures prove conflicts serialize, independent resources may overlap and child
exit 7 propagates with healthy release. Expected denial/queue timeout is not a
passing real workload; actual wired-host overlap proof remains Piece 14.

### PA-08-V — Verify the graph/lifecycle and repair wiring-source gaps

Apply the full verifier routine. Inspect all conflict aliases/paths/order,
unwrapped inner commands, limits, reentry lineage, watchdog and retention rules.
Repair approved source/config gaps; no sidecar deletion or release of unknown
work. Expected denied recovery must satisfy safety assertions, not be "fixed"
to permit takeover. Accept staged scope or genuine gate-false applicability.

## Piece 09 — Generated-file races, if applicable

### PA-09-I — Stage generated-output coordination and diagnosis

**Inputs/stage:** verified Phase 5 gate and resource graph; conditional source.

Inventory all client/schema/type regenerators and shared outputs. Stage one
consistent exclusion route for each conflicting writer, preserving coverage and
legitimate output contracts. For reported missing-export/parse symptoms, perform
only actually authorized bounded isolation to distinguish race from source bug;
retain evidence rather than silently rerun until green. No generator means
evidenced not applicability, not invented codegen machinery.

**Acceptance:** complete writer graph/staged protection and Regression Guard.
Expected rejection/race reproduction can fulfill diagnostic checks; unresolved
real output corruption still fails a repair requirement. Host proof stays deferred.

### PA-09-V — Verify coverage and repair coordination omissions

Apply the full verifier routine. Check every generator alias/hook and its lock
identity, preserved outputs/discovery and actual diagnostic budgets/provenance.
Repair approved inactive source; do not quarantine generation failures or broaden
retries. Retain runtime exclusion/output integrity proof for Piece 14.

## Piece 10 — Test hygiene and governed failure assessment

### PA-10-I — Stage applicable timer/pool/evidence safeguards

**Inputs/stage:** Phase 6 applicability, actual canonical policy and harness;
staged safeguards plus explicitly permitted diagnostics.

Preserve framework timer isolation/restoration; avoid cross-file TTL/clock resets.
Add appropriate background pool error handling only where those pools exist.
Track pre-existing failures under authoritative applicable policy without skipped,
filtered, renamed, deleted or undiscovered required coverage.

When Failure Gate is active, retain owned repairs, exact active unexpired catalog
matches, raw failures and all-tier-step accounting. Unlisted classification uses
exactly three authorized isolation retries with matching environment/provenance,
independent corroboration, bounded scope and retained consumption, or the actually
approved equivalent policy. A passing retry is intermittency, not provenance.
No automatic quarantine, waiver, catalog broadening or tier change.

**Acceptance:** staged hygiene/assessment implementation and required evidence
within approved scope. An assertion expecting rejection/failure is not a failing
assertion or an ignored baseline. Missing provenance still blocks a task that
requires that classification; administrative closure is not validated success.

### PA-10-V — Verify policy/timer handling and repair scoped omissions

Apply the full verifier routine. Check actual policy applicability, timer/pool
gates, coverage, exact catalog/provenance, retry accounting and raw/assessment
separation. Repair approved code/records only with Regression Guard; never rewrite
FAIL/BLOCKED/INCOMPLETE to clean PASS or suppress owned repair. Preserve current-
snapshot checked evidence and complete-tier acceptance for Piece 14.

## Piece 11 — WebSockets and preview HMR, if applicable

### PA-11-I — Stage evidenced keepalive/lifecycle changes

**Inputs/stage:** Phase 7 gate and actual idle/reconnection evidence;
conditional inactive adaptation.

If absent or no supported need, record the gate decision without adding heartbeat
machinery. Treat historical 30-second proxy/20-second ping values as clues, not
universal contracts. Where supported/needed, stage protocol-level server pings,
timer/connection cleanup and reconnect handling; application JSON heartbeats are
not protocol pings and browsers lack a native ping API.

**Acceptance:** evidence-based staged changes and Regression Guard with permitted
fixtures for idle, reconnect and teardown. Expected fixture disconnection can
pass that negative assertion, not prove actual preview reconnection fixed.

### PA-11-V — Verify gate/lifecycle and repair approved source gaps

Apply the full verifier routine. Check supported protocol semantics, selected
interval rationale, resource cleanup, reconnect contract and absence of speculative
changes. Repair approved inactive lifecycle source only; retain actual idle/
preview behavior acceptance for Piece 14.

## Piece 12 — API/browser health probes and managed restarts

### PA-12-I — Stage the actual health contract and regressions

**Inputs/stage:** Phase 8 actual endpoint/service/browser routing, existing
infrastructure and approved source scope; staged probe changes.

For an API project, stage a probe of its actual expected status, JSON-compatible
media type, parseable body and exact healthy fields/types/identity, using the
real routed browser request as applicable. No universal endpoint/ok field or
unnecessary backend for a static-only project. An out-of-scope JSON contract
change remains a blocker, not a fake healthy HTML fallback.

Stage positive and negative regressions for valid healthy JSON, HTML-200 through
frontend routing, media/body/identity failures, redirects, unhealthy JSON,
HTTP/network errors and abort/timeout. Use supported isolated routes for negative
cases, not a live outage. Preserve credentials/private bodies. Record authorized
managed restart/cutover needs rather than assume hot reload applied config.

**Acceptance:** correct staged real-path probe and regression implementation with
Regression Guard and finite request/cumulative cancellation. Expected health
rejections pass negative assertions, not actual backend health. Actual managed
restart, browser route and genuine healthy response remain Piece 14.

### PA-12-V — Verify real-path contract and repair probe-source omissions

Apply the full verifier routine. Trace endpoint/proxy/base URL/auth/method and
expected identity/shape, inspect all positive/negative cases and finite aborts.
Repair approved probe/test source only; no live service stop to manufacture proof.
Accept staged scope or evidenced static-only nonapplicability, retaining real
runtime health/restart obligations and out-of-scope contract dependencies.

## Piece 13 — Real attestation/reclaim integration, only if selected

### PA-13-I — Implement and prove genuine scoped authority

**Inputs/stage:** explicit approved live-reclaim/development-exception scope,
real independent providers and exact disruption/test targets; actual capability
and caller acceptance, NOT a fixture/source stage.

If the selected installation truly needs neither reclaim nor the exception,
record evidenced nonapplicability; do not invent an approval platform.
Otherwise integrate the code-owned boundary with genuine host identity/
attestation and checked Failure Gate claim/recheck/outcome sources under exact
task/approved-plan/run scope. Preserve freshness, revocation, root/boot/ancestor/
incarnation/UID binding, production hard stops, claim/replay/conflict protection,
per-signal authority and acknowledged outcomes. No dynamic verifier selection.

Prove required live negative denials cannot signal/dispatch and exact approved
fixture-owned or explicitly approved scoped host operations reach the contract's
state with durable outcome evidence. Real live checks require exact authorization;
test-only adapters/local manifests cannot establish genuine capability.
Reconcile uncertain claims/writes by stable identities, never blind retries.

**Acceptance:** actual verified providers and all selected scoped acceptance.
Correct rejected operations can pass negative assertions; missing real providers
remain a genuine blocker for this implementation task. Never bypass to finish.

### PA-13-V — Independently verify actual authority and scoped operations

Apply the full verifier routine against provider/runtime evidence, not source
comments, mock success or forged records. Check real denial/no-signal paths,
expiry/escalation, evidence acknowledgement, retained uncertainty and exact
targets. Repairs require explicit provider/code scope and renewed exact live-test
authorization; do not install substitute approval or weaken hard flags.
Accept only the verified selected scope, with independently accepted post-repair
proof. If unavailable, retain current obligation and exact provider/owner proposal.

## Piece 14 — Authorized cutover, twice-run host acceptance and migration

### PA-14-I — Activate the selected controls and prove real callers

**Inputs/stage:** all required accepted prior stages, delivered snapshots,
real readiness gates, exact authorized cutover/disruption/recovery boundaries;
actual host acceptance.

Re-audit current native plans, policy, running work, transitive callers, resource/
port bindings and approved scope; drift invalidates affected earlier evidence.
Apply staged changes only through authorized cutover. Preserve safe existing
wiring until then; unsafe/uncertain legacy rollback is a blocker, not a baseline.
Migrate legacy leases/PID-only callers/helpers and obsolete Heavy references only
within approved scope; never edit mirrors or auto-migrate other projects.

Verify actual managed workflows/ports, any applicable browser ordering, all
conflicting caller identities/order, generated outputs, timer/pool safeguards,
idle HMR and actual browser/API JSON health. Non-reclaim callers must not
transitively invoke unavailable reclaim. Selected reclaim uses real checked
providers/targets/outcome evidence; no production or external CI scope implied.

Run the actual authorized applicable tier/host acceptance twice back-to-back on
current inputs without manual port/process/lease cleanup between. Preserve complete
coverage, raw results and allowed ignored-failure assessments, actual finite
all-entry-point supervision, remaining parent budgets and current-snapshot evidence.
Negative assertions may intentionally reject; unexpected suite failure, survivors,
missing reports, manual intervention or quarantined required coverage cannot pass.

**Acceptance:** per-control NON_RECLAIM_VERIFIED or LIVE_RECLAIM_ENABLED only when
all existing actual-host requirements hold. Stage-only assets remain STAGED.
Missing host proof blocks this task even if earlier package/fixture tasks completed.
Report exact installed/blocked/unselected controls and retained incidents, never
blanket "operational" from a status, source parity or mock.

### PA-14-V — Independently verify the complete selected installation

Apply the full verifier routine against actual delivered wiring/current source,
full mandatory matrix-to-code mapping and both real host reports. Recheck every
conditional gate, all entry points, actual authority, health/browser routes,
termination/exclusion evidence and Failure Gate assessment where applicable.
List gaps first; repair only explicitly approved installation scope, refresh
bindings and renew affected complete host acceptance twice within remaining
authority/budgets. Obtain independent post-repair review, not author self-report.
Accept only the selected scope with full evidence. No automatic merge/deploy,
native status rewrite, lease release, administrative waiver or follow-up series.

## Required verifier report

Record the actual project/task/specification/package/source/environment bindings,
declared stage and delivered inputs. For EACH applicable acceptance item list:
expected outcome; actual raw outcome/state; assertions and evidence; criterion
assessment; genuine remaining blocker; responsible role; smallest authorized
resume route. Keep expected non-zero results visible even for an accepted task.

Include gaps before edits, authorized amendments, invalidated/renewed evidence,
independent post-repair acceptance reference, test/host fixture separation,
coverage/tier/route/finite-limit accounting, retained incidents and deferred
later-task obligations. No diagnosis may silently become an approval/waiver.

## Materialization and resumption

The deliverable is ready for review/import as a planning specification only.
To initialize elsewhere, bind the actual project, supplied package, complete plan,
canonical target-required contracts and drafting authority. Preserve all shared
instructions in both native plans plus their complete individual payloads.
Resolve target-required confirmation batching and capability uncertainties BEFORE
writing tasks. Start with Piece 01 only, as drafts for ordinary user approval.

Resume by authoritative readback of current pair, acceptance and delivered
outputs; prepare only the next eligible pair under actual conditional drafting
authority. Failed/incomplete obligations remain current; accepted diagnostic
findings retain downstream gates without falsely blocking their own completion.
Invocation-driven progression is the default. This plan installs no wake-up hook.
