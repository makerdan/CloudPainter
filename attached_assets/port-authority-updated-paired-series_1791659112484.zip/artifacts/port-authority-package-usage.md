# Updated Port Authority package — use and limits

The canonical package is `.agents/skills/port-authority/` with exactly seven
files. Its entry point and runtime reference now distinguish expected negative/
non-zero outcomes from genuinely unmet task requirements, reinforced in individual
phases. The four runtime scripts and existing test suite are unchanged.

`port-authority-paired-installation-series.md` is a separate 14-piece planning
specification: each piece has an implementation and independent verifier payload.
It is not 28 native task cards and has not initialized a project series.

## Install the definition only

Supply the complete canonical package to the intended project. Request:

> Install/update this canonical seven-file Port Authority package under
> .agents/skills/port-authority, preserving references, runtime files and modes.
> Follow any mandatory definition/resource confirmation contracts. Do not
> initialize a task series, wire callers, activate reclaim, run tests, stop
> services, schedule work, merge or deploy merely from this package installation.

Source installation is distinct from runtime adaptation and acceptance. If a
canonical destination already exists, reconcile the authorized baseline before
overwriting it. No deliverable belongs under `.local/`.

## Prepare a series after selecting a project and scope

Supply the complete package and series document. Request:

> Read the canonical Port Authority package and full paired-installation series.
> Bind this project and the exact installation scope. Use canonical
> paired-task-orchestration and Router contracts where present/applicable, never
> mirrors. Reconcile mandatory confirmation/resource-verification batching first.
> Prepare only Piece 01's complete implementation and dependent verifier plans
> as drafts for my approval; do not start them. Keep later pieces as backlog.
> Preserve the expected-outcome contracts, source/fixture/host stages and all
> live authority, validation, coverage, budget and disruption gates.

Successor drafting is not authorized by this document alone. If wanted, separately
grant conditional permission to prepare each next draft pair after current-stage
independent acceptance and delivered outputs; approval/execution remains separate.
Default resumption is invocation-driven, not an installed callback or scheduler.

Resume instruction:

> Reconcile the current Port Authority pair and prepare the next pair only if its
> declared stage has accepted current evidence and its outputs are delivered.
> Expected negative/non-zero results are assessed against their declared criteria;
> do not treat them as blockers merely by their value or label.

## What completion means

An audit can complete by correctly finding a missing provider. A rejection test
can complete by observing the expected exit 2/3/4 and the required no-signal
evidence. An isolated regression task can complete without host activation.
Those completed tasks do not establish genuine provider availability, FREE ports
or working real callers. A live-reclaim or host-acceptance task remains blocked
if its own required authority, implementation or evidence is missing.

No target project, native task, running workflow, provider, lease, service, approval
record, remote CI configuration, schedule or deployment was changed by authoring
this package and plan. Workspace publication and project installation are separate.
